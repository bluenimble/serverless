package com.settletop.impls;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.settletop.ApiRequestBodyReader;
import com.settletop.impls.readers.ApiRequestBodyJsonReader;
import com.settletop.impls.readers.ApiRequestBodyMultilineJsonReader;
import com.settletop.impls.readers.ApiRequestBodyTextReader;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.Encodings;
import com.settletop.utils.Lang;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

public class DefaultApiRequest extends AbstractApiRequest {
	
	private static final Map<String, ApiRequestBodyReader> Readers = new HashMap<String, ApiRequestBodyReader>();
	static {
		Readers.put (ContentTypes.Text.toUpperCase (), new ApiRequestBodyTextReader ());
		Readers.put (ContentTypes.Json.toUpperCase (), new ApiRequestBodyJsonReader ());
		Readers.put (ContentTypes.MultiJson.toUpperCase (), new ApiRequestBodyMultilineJsonReader ());
	}
	
	private HttpExchange exchange;
	
	public DefaultApiRequest (HttpExchange exchange) throws Exception {
		this.exchange = exchange;
		
		this.readHeaders 	();
		this.readParameters ();
		this.readBody 		();
		
	}

	@Override
	public String getVerb () {
		return exchange.getRequestMethod ().toUpperCase ();
	}

	@Override
	public String getPath () {
		return exchange.getRequestURI ().getPath ();
	}

	@Override
	public Channel getChannel () {
		return Channel.Http;
	}

	public Object getBody () {
		if (this.body == null) {
			return exchange.getRequestBody ();
		}
		return super.getBody ();
	}
	
	private void readBody () throws Exception {
		String verb = this.getVerb ();
		if (!verb.equals (Verbs.Post) && !verb.equals (Verbs.Put)) {
			return;
		}
		String contentType = this.getContentType ();
		if (Lang.isNullOrEmpty (contentType)) {
			return;
		}
		
		ApiRequestBodyReader reader = Readers.get (contentType.toUpperCase ());
		if (reader == null) {
			return;
		}
		this.body = reader.read (exchange.getRequestBody ());
	}
	
	private void readHeaders () {
		Headers headers = exchange.getRequestHeaders ();
		Iterator<String> names = headers.keySet ().iterator ();
		while (names.hasNext ()) {
			String name = names.next ();
			this.headers.put (name.toUpperCase (), headers.get (name).get (0));
		}
	}
	
	private void readParameters () {
		String query = exchange.getRequestURI ().getQuery ();
		if (Lang.isNullOrEmpty (query)) {
			return;
		}
		parameters = new HashMap<String, Object>();
		String [] aQuery = Lang.split (exchange.getRequestURI ().getQuery (), Lang.AMP);
		for (String nv : aQuery) {
			if (nv.indexOf (Lang.EQUALS) <= 0) {
				parameters.put (decode (nv), true);
				continue;
			}
			String [] anv = Lang.split (nv, Lang.EQUALS);
			parameters.put (decode (anv [0]), decode (anv [1]));
		}
	}
	
	private String decode (String encoded) {
	    try {
	        return encoded == null ? null : URLDecoder.decode (encoded, Encodings.UTF8);
	    } catch (UnsupportedEncodingException e) {
	        return null;
	    }
	}
	
}
