package com.settletop.impls;

import java.io.File;
import java.io.FileFilter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.ApiService;
import com.settletop.ApiServiceRegistry;
import com.settletop.ApiServiceWrapper;
import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.utils.BeanUtils;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;
import com.settletop.utils.WildcardCompiler;
import com.settletop.utils.WildcardMatcher;

public class DefaultApiServiceRegistry implements ApiServiceRegistry {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServiceRegistry.class);
	
	private static final String JsonExtension	= ".json";
	private static final String ServicesFolder 	= "services";
	
	public interface ServiceEndpointSpec {
		String Name 		= "name";
		String Unary 		= "unary";
		String Accessors	= "accessors";
	}
	
	private File home;
	
	private Map<String, String> 	servicesByPath 	= new HashMap<String, String>();
	private Map<String, JsonObject> serviceSpecs 	= new HashMap<String, JsonObject>();

	private Map<String, ApiService> services 		= new HashMap<String, ApiService>();
	
	public DefaultApiServiceRegistry (File home) throws Exception {
		this.home = home;
		this.loadServices ();
	}
	
	public ApiServiceWrapper lookup (String id) {
		return new ApiServiceWrapper (serviceSpecs.get (id), services.get (id));
	}
	
	public ApiServiceWrapper lookup (String verb, String path) {
		if (path.endsWith (Lang.SLASH)) {
			path = path.substring (0, path.length () - 1);
		}
		String endpoint = verb.toUpperCase () + Lang.COLON + path;
		String serviceId = servicesByPath.get (endpoint);
		if (serviceId != null) {
			return new ApiServiceWrapper (serviceSpecs.get (serviceId), services.get (serviceId));
		}
		Iterator<String> paths = servicesByPath.keySet ().iterator ();
		while (paths.hasNext ()) {
			String sPath 	= paths.next ();
			String sId 		= servicesByPath.get (sPath);
			WildcardMatcher matcher = new WildcardMatcher (WildcardCompiler.compile (sPath), endpoint);
			if (matcher.find ()) {
				return this.lookup (sId);
			}
		}
		return null;
	}
	
	private void loadServices () throws Exception {
		File servicesFolder = new File (this.home, ServicesFolder);
		if (!servicesFolder.exists ()) {
			return;
		}
		this.loadServices (servicesFolder);
		Logger.info ("(" + services.size () + ") API endpoints running\n");
	}
	
	private void loadServices (File folder) throws Exception {
		File [] files = folder.listFiles (new FileFilter () {
			public boolean accept (File file) {
				return file.isDirectory () || file.getName ().endsWith (JsonExtension);
			}
		});
		
		for (File file : files) {
			if (file.isDirectory ()) {
				this.loadServices (file);
				continue;
			}
			this.addService (Json.load (file));
		}
	}
	
	private void addService (JsonObject serviceSpec) throws Exception {
		String endpoint = Json.getString (serviceSpec, Service.Endpoint).substring (1);
		
		boolean doubleColonFound = false;
		
		JsonArray aAccessors = new JsonArray ();
		
		String [] accessors = Lang.split (endpoint, Lang.SLASH);
		for (int i = 0; i < accessors.length; i++) {
			String accessor = accessors [i];
			if (accessor.startsWith (Lang.COLON + Lang.COLON)) {
				if (doubleColonFound) {
					break;
				}
				doubleColonFound = true;
				endpoint = Lang.replace (endpoint, accessor, Lang.STAR + Lang.STAR);
				aAccessors.add (new JsonObject ().set (ServiceEndpointSpec.Name, accessor.substring (2)).set (ServiceEndpointSpec.Unary, false));
				continue;
			}
			if (accessor.startsWith (Lang.COLON)) {
				endpoint = Lang.replace (endpoint, accessor, Lang.STAR);
				aAccessors.add (new JsonObject ().set (ServiceEndpointSpec.Name, accessor.substring (1)).set (ServiceEndpointSpec.Unary, true));
				continue;
			}
			aAccessors.add (accessor);
		}
		
		serviceSpec.set (ServiceEndpointSpec.Accessors, aAccessors);
		
		String serviceId = Json.getString (serviceSpec, Service.Id);
		if (Lang.isNullOrEmpty (serviceId)) {
			serviceId = Lang.oid ();
		}
		
		serviceSpecs.put (serviceId, serviceSpec);
		
		servicesByPath.put (
			Json.getString (serviceSpec, Service.Verb, Defaults.Verb).toUpperCase () + Lang.COLON + Lang.SLASH + endpoint, 
			serviceId
		);
		
		String serviceSpi = Json.getString (serviceSpec, Service.Spi);
		if (Lang.isNullOrEmpty (serviceSpi)) {
			return;
		}
		
		services.put (serviceId, (ApiService)BeanUtils.create (serviceSpi, null));
	}
	
}
