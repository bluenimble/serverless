package com.settletop.platform.security.impls;

import java.io.File;

import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecretsProvider;
import com.settletop.server.ApiServer;
import com.settletop.utils.Json;

public class PlainSecretsProvider implements SecretsProvider {
	
	private static final String SecretsFile = "secrets.json";
	
	private JsonObject secrets;
	
	public PlainSecretsProvider () {
	}
	
	@Override
	public void initialize (ApiServer server, JsonObject spec) {
		try {
			this.secrets = Json.load (new File (server.getHome (), SecretsFile));
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
	}

	@Override
	public JsonObject lookup (String name) {
		return Json.getObject (secrets, name);
	}

}
