package com.settletop.platform.security.impls;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiServiceRegistry;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecurityAgent;
import com.settletop.platform.security.SecurityAgentException;
import com.settletop.server.ApiServer;

public class NoSecurityAgent implements SecurityAgent {
	
	@Override
	public void initialize (ApiServer server, JsonObject spec) {
	}

	public JsonObject issueToken (JsonObject payload, int ageInMinutes) {
		return JsonObject.Blank;
	}
	
	@Override
	public ApiConsumer check (ApiContext context, ApiRequest request, ApiResponse response, ApiServiceRegistry registry,
			JsonObject specification) throws SecurityAgentException {
		// write an 403 error
		response.writeError (401, NoSecurityAgent.class.getSimpleName ());
		// raise an error
		throw new SecurityAgentException (NoSecurityAgent.class.getSimpleName ());
	}

}
