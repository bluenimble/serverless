package com.settletop.server.boot;

import com.settletop.server.ApiServer;
import com.settletop.server.StartApiServerException;
import com.settletop.server.impls.DefaultApiServer;

public class Server {

	public static void main (String[] args) throws StartApiServerException {
		
		String version = args.length > 0 ? args[0] : "0.0.0";
		
		final ApiServer apiServer = new DefaultApiServer (version);
		apiServer.start ();
		
		Runtime.getRuntime ().addShutdownHook (new Thread () {
			public void run () {
				apiServer.stop ();
			}
		});
	}

}
