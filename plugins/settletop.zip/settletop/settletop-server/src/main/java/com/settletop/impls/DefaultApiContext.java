package com.settletop.impls;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.ApiServiceWrapper;
import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecurityAgent;
import com.settletop.platform.services.Releasable;
import com.settletop.platform.services.database.Database;
import com.settletop.platform.services.database.DatabaseService;
import com.settletop.platform.services.indexer.Indexer;
import com.settletop.platform.services.indexer.IndexerService;
import com.settletop.server.impls.DefaultApiServer;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class DefaultApiContext implements ApiContext {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiContext.class);
	
	private static final String ServiceNotFound 			= "Service not found";
	private static final String ServiceHasNoImplementation 	= "Service has no implementation";
	
	interface Defaults {
		String Database = "database.default";
		String Indexer 	= "indexer.default";
	}
	
	private DefaultApiServer server;
	
	private Map<String, Object> platformServices = new HashMap<String, Object>();
	
	public DefaultApiContext (DefaultApiServer server) {
		this.server = server;
	}

	@Override
	public Database getDatabase (String name, boolean trx) {
		if (Lang.isNullOrEmpty (name)) {
			name = Defaults.Database;
		}
		
		Database instance = (Database)platformServices.get (name);
		if (instance != null) {
			return instance;
		}
		
		Object oService = server.getPlatformService (name);
		if (!(oService instanceof DatabaseService)) {
			return null;
		}
		instance = ((DatabaseService)oService).get (trx);
		platformServices.put (name, instance);
		return instance;
	}

	@Override
	public Indexer getIndexer (String name) {
		if (Lang.isNullOrEmpty (name)) {
			name = Defaults.Indexer;
		}
		Indexer instance = (Indexer)platformServices.get (name);
		if (instance != null) {
			return instance;
		}
		
		Object oService = server.getPlatformService (name);
		if (!(oService instanceof IndexerService)) {
			return null;
		}
		instance = ((IndexerService)oService).get ();
		platformServices.put (name, instance);
		return instance;
	}

	@Override
	public SecurityAgent getSecurityAgent () {
		return this.server.getSecurityAgent ();
	}
	
	public void release (boolean success) {
		Iterator<String> keys = platformServices.keySet().iterator ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			Object instance = platformServices.get (key);
			if (Releasable.class.isAssignableFrom (instance.getClass ())) {
				((Releasable)instance).release (success);
			}
		}
	}

	@Override
	public ApiServiceOutput execute (ApiConsumer consumer, ApiRequest request, ApiResponse response) throws ApiServiceExecutionException {
		ApiServiceWrapper serviceWrapper = 
			this.server.getServiceRegistry ().lookup (
				request.getVerb (),
				request.getPath ()
			);
		
		if (serviceWrapper == null) {
			response.writeError (404, ServiceNotFound);
			return null;
		}
		
		if (serviceWrapper.getService () == null) {
			JsonObject output = Json.getObject (serviceWrapper.getSpecification (), ApiServiceRegistry.Service.Response);
			if (output != null) {
				response.writeJson (output);
				return null;
			}
			response.writeError (404, ServiceHasNoImplementation);
		}
		
		Logger.info (" -> Found service matching endpoint - " + serviceWrapper.getService ().getClass ().getSimpleName ());
		
		// resolve request path parameters
		resolveParameters (request, Json.getArray (serviceWrapper.getSpecification (), DefaultApiServiceRegistry.ServiceEndpointSpec.Accessors));

		ApiServiceOutput output = null;
				
		try {
			output = serviceWrapper.getService ().execute (
				this, consumer, request, response, server.getServiceRegistry (), serviceWrapper.getSpecification ()
			);
		} finally {
			request.recycle ();
		}
		
		return output;
	}
	
	private void resolveParameters (ApiRequest request, JsonArray accessors) {
		
		String path = request.getPath ();
		if (Lang.isNullOrEmpty (path) || path.equals (Lang.SLASH)) {
			return;
		}
		
		if (path.endsWith (Lang.SLASH)) {
			path = path.substring (0, path.length () - 1);
		}
		
		String [] aPath = Lang.split (request.getPath ().substring (1), Lang.SLASH);

		for (int i = 0; i < accessors.count (); i++) {
			Object accessor = accessors.get (i);
			if (!(accessor instanceof JsonObject)) {
				continue;
			}
			
			JsonObject oAccessor = (JsonObject)accessor;
			
			if (Json.getBoolean (oAccessor, DefaultApiServiceRegistry.ServiceEndpointSpec.Unary, true)) {
				request.addParameter (Json.getString (oAccessor, DefaultApiServiceRegistry.ServiceEndpointSpec.Name), aPath [i]);
				continue;
			}
			
			// **
			String subPath = Lang.BLANK;
			for (int j = i; j < aPath.length; j++) {
				subPath += aPath [j];
			}
			request.addParameter (Json.getString (oAccessor, DefaultApiServiceRegistry.ServiceEndpointSpec.Name), subPath);
			return;
		}
		
	}

}
