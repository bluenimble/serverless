package com.settletop.server.impls;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.ApiConsumer;
import com.settletop.ApiResponse;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceWrapper;
import com.settletop.impls.DefaultApiContext;
import com.settletop.impls.DefaultApiRequest;
import com.settletop.impls.DefaultApiResponse;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecurityAgentException;
import com.settletop.utils.Lang;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class DefaultApiServerHandler implements HttpHandler {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServerHandler.class);
	
	private static final String ServiceNotFound 			= "Service not found";
	
	private DefaultApiServer server;
	
	public DefaultApiServerHandler (DefaultApiServer server) {
		this.server = server;
	}

	public void handle (HttpExchange exchange) throws IOException {
		
		Logger.info ("New Request " + exchange.getRequestMethod () + Lang.COLON + exchange.getRequestURI ().getPath ());
		
		long start = System.currentTimeMillis ();

		DefaultApiContext 	context 	= new DefaultApiContext (this.server);
		DefaultApiRequest 	request		= null;
		ApiResponse 		response	= new DefaultApiResponse (exchange);
		ApiServiceOutput  	output 		= null;
		ApiConsumer 		consumer	= null;
		
		try {
			request = new DefaultApiRequest (exchange);
		} catch (Exception e) {
			Logger.error ("", e);
			response.writeError (500, e.getMessage ());
		}
		
		ApiServiceWrapper serviceWrapper = 
			this.server.getServiceRegistry ().lookup (
				request.getVerb (),
				request.getPath ()
			);
		
		if (serviceWrapper == null) {
			response.writeError (404, ServiceNotFound);
			return;
		}
		
		try {
			consumer = this.server.getSecurityAgent ().check (
				context, request, response, server.getServiceRegistry (), serviceWrapper.getSpecification ()
			);
			output = context.execute (consumer, request, response);
		} catch (SecurityAgentException e) {
			// agent supposed to send over the response
			Logger.error ("", e);
			response.writeError (e.getCode (), e.getMessage ());
			context.release (false);
		} catch (ApiServiceExecutionException e) {
			// agent supposed to send over the response
			Logger.error ("", e);
			response.writeError (e.getCode (), e.getMessage ());
			context.release (false);
		} catch (Exception e) {
			Logger.error ("", e);
			response.writeError (500, e.getMessage ());
			context.release (false);
		}
		
		// release with success
		context.release (true);
				
		Logger.error (" -> " + serviceWrapper.getService ().getClass ().getSimpleName () + " took " + (System.currentTimeMillis () - start) + " millis");
		
		// write response
		if (output == null) {
			response.writeJson (JsonObject.Blank);
			return;
		}
		
		output.writeTo (response);
	}

}
