package com.settletop.server.impls;

import java.io.File;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.ApiServiceRegistry;
import com.settletop.impls.DefaultApiServiceRegistry;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecretsProvider;
import com.settletop.platform.security.SecurityAgent;
import com.settletop.platform.security.impls.NoSecurityAgent;
import com.settletop.platform.security.impls.PlainSecretsProvider;
import com.settletop.server.ApiServer;
import com.settletop.server.StartApiServerException;
import com.settletop.utils.BeanUtils;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;
import com.sun.net.httpserver.HttpServer;

public class DefaultApiServer implements ApiServer {
	
	private static final Logger Logger 				= LoggerFactory.getLogger (DefaultApiServer.class);
	
	private static final String Copyright 			= "Copyright (c) SettleTop, Inc. (https://settletop.com)";

	private static final String ServerConfig 		= "server.json";
	
	private static final String InitializeMethod	= "initialize";
	
	interface Spec {
		String Name				= "name";
		String Version			= "version";
		
		String Host 			= "host";
		String Port 			= "port";
		String ThreadPool		= "threadPool";
		String Context			= "context";
		String Clazz			= "class";

		interface Platform {
			String Spec				= "spec";
			String Services 		= "services";

			String SecurityAgent	= "securityAgent";
			String SecretsProvider	= "secretsProvider";
		}
	}
	
	interface Defaults {
		String 	Name		= "SettleTop Server";
		String	Version		= "0.0";
		String 	Host 		= "localhost";
		Integer Port 		= 9090;
		Integer ThreadPool	= 100;
		String 	Context		= "/";
	}
	
	private String 				version;
	private File 				home;
	
	private JsonObject 			config;
	private HttpServer 			server;
	
	private SecurityAgent		securityAgent;
	private SecretsProvider	   	secretsProvider;
	
	private ApiServiceRegistry 	serviceRegistry;
	
	private Map<String, Object>	platformServices = new HashMap<String, Object> ();
	
	public DefaultApiServer (String version) {
		this.version = version;
	}
	
	public void start () throws StartApiServerException {
		
		long start = System.currentTimeMillis ();
		
		this.home = new File (System.getProperty ("user.dir"));
		
		this.config = null;
		
		File configFile = new File (home, ServerConfig);
		
		if (configFile.exists ()) {
			// load the server config
			try {
				this.config = Json.load (configFile);
			} catch (Exception e) {
				throw new StartApiServerException (e);
			}
		} else {
			this.config = (JsonObject)new JsonObject ().set (Spec.Name, Defaults.Name).set (Spec.Version, Defaults.Version);
		}
		
		System.out.println ();
		System.out.println (Lang.SPACE + Json.getString (config, Spec.Name, Defaults.Name) + " Version " + this.version);
		System.out.println (Lang.SPACE + Copyright);
		System.out.println ();
		
		try {
			// initialize the secrets provider & platform services
			this.initializePlatformServices ();
			
			// create a server instance
			String host = Json.getString (this.config, Spec.Host, Defaults.Host);
			server = HttpServer.create (
				Lang.isNullOrEmpty (host) ?
				new InetSocketAddress (
					Json.getInteger (this.config, Spec.Port, Defaults.Port)
				) : 
				new InetSocketAddress (
					Json.getString (this.config, Spec.Host, Defaults.Host), 
					Json.getInteger (this.config, Spec.Port, Defaults.Port)
				),
				0
			);
			
			// load services specifications
			this.serviceRegistry = new DefaultApiServiceRegistry (home);
			
			// start the server instance
			ThreadPoolExecutor threadPoolExecutor = 
				(ThreadPoolExecutor)Executors.newFixedThreadPool (Json.getInteger (this.config, Spec.ThreadPool, Defaults.ThreadPool));
			
			server.createContext (Json.getString (this.config, Spec.Context, Defaults.Context), new DefaultApiServerHandler (this));
			server.setExecutor (threadPoolExecutor);
			server.start ();
			Logger.info ("Server took ( ~ " + Math.round ((System.currentTimeMillis () - start) / 1000) + " seconds ) to start | listening on port " + Json.getInteger (this.config, Spec.Port, Defaults.Port) + Lang.ENDLN);
		} catch (Exception e) {
			throw new StartApiServerException (e);
		}
	}
	
	public void stop () {
		server.stop (0);
	}
	
	public File getHome () {
		return home;
	}
	
	public JsonObject getConfiguration () {
		return config;
	}
	
	public SecurityAgent getSecurityAgent () {
		return securityAgent;
	}
	
	public SecretsProvider getSecretsProvider () {
		return secretsProvider;
	}
	
	public ApiServiceRegistry getServiceRegistry () {
		return serviceRegistry;
	}
	
	public Object getPlatformService (String name) {
		return platformServices.get (name);
	}
	
	private void initializePlatformServices () throws Exception {
		// setup the secrets provider
		JsonObject oSecretsProvider = (JsonObject)Json.find (this.config, Spec.Platform.class.getSimpleName ().toLowerCase (), Spec.Platform.SecretsProvider);
		if (oSecretsProvider != null) {
			this.secretsProvider = (SecretsProvider)BeanUtils.create (Json.getString (oSecretsProvider, Spec.Clazz), null);
		} else {
			this.secretsProvider = new PlainSecretsProvider ();
		}
		Method initMethod = this.secretsProvider.getClass ().getMethod (InitializeMethod, new Class [] { ApiServer.class, JsonObject.class });
		initMethod.invoke (this.secretsProvider, new Object [] { this, Json.getObject (oSecretsProvider, Spec.Platform.Spec) });

		Logger.info ("Using Secrets  Provider " + this.secretsProvider.getClass ().getName ());
		
		// setup security agent
		JsonObject oSecurityAgent = (JsonObject)Json.find (this.config, Spec.Platform.class.getSimpleName ().toLowerCase (), Spec.Platform.SecurityAgent);
		if (oSecurityAgent != null) {
			this.securityAgent = (SecurityAgent)BeanUtils.create (Json.getString (oSecurityAgent, Spec.Clazz), null);
			initMethod = this.securityAgent.getClass ().getMethod (InitializeMethod, new Class [] { ApiServer.class, JsonObject.class });
			initMethod.invoke (this.securityAgent, new Object [] { this, Json.getObject (oSecurityAgent, Spec.Platform.Spec) });
		} else {
			this.securityAgent = new NoSecurityAgent ();
		}
		Logger.info ("Using Security Agent    " + this.securityAgent.getClass ().getName () + Lang.ENDLN);
		
		// platform services
		JsonObject platformServices = (JsonObject)Json.find (this.config, Spec.Platform.class.getSimpleName ().toLowerCase (), Spec.Platform.Services);
		if (platformServices == null) {
			return;
		}
		
		Logger.info ("Found (" + platformServices.size () + ") platform services\n");
		
		Iterator<String> keys = platformServices.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			Logger.info ("  -> Initialize platform service " + key + Lang.ENDLN);
			JsonObject service = Json.getObject (platformServices, key);
			Object platformService = BeanUtils.create (Json.getString (service, Spec.Clazz), null);
			initMethod = platformService.getClass ().getMethod (InitializeMethod, new Class [] { ApiServer.class, JsonObject.class });
			initMethod.invoke (platformService, new Object [] { this, Json.getObject (service, Spec.Platform.Spec) });
			this.platformServices.put (key, platformService);
		}
	}
	
}
