#!/bin/sh
#
# Copyright (c) SettleTop, Inc. (https://settletop.com)
#

# resolve links - $0 may be a softlink
PRG="$0"

while [ -h "$PRG" ]; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
    PRG="$link"
  else
    PRG=`dirname "$PRG"`/"$link"
  fi
done

# Get standard environment variables
PRGDIR=`dirname "$PRG"`

# Only set SETTLETOP_HOME if not already set
[ -f "$SETTLETOP_HOME"/SETTLETOP.sh ] || SETTLETOP_HOME=`cd "$PRGDIR" ; pwd`
export SETTLETOP_HOME

# Raspberry Pi check (Java VM does not run with -server argument on ARMv6)
if [ `uname -m` != "armv6l" ]; then
  JAVA_OPTS="$JAVA_OPTS -server "
fi
export JAVA_OPTS

# Set JavaHome if it exists
if [ -f "${JAVA_HOME}/bin/java" ]; then 
   JAVA=${JAVA_HOME}/bin/java
else
   JAVA=java
fi
export JAVA

JAVA_OPTS_SCRIPT="-Djna.nosys=true -Dhttps.protocols=TLSv1,TLSv1.1,TLSv1.2 -XX:+HeapDumpOnOutOfMemoryError -XX:MaxDirectMemorySize=7879m -Djava.awt.headless=true -Dfile.encoding=UTF8 -Djava.net.preferIPv4Stack=true -DSETTLETOP_HOME=$SETTLETOP_HOME"

SETTLETOP_PID=$SETTLETOP_HOME/SETTLETOP.pid

if [ -f "$SETTLETOP_PID" ]; then
    rm "$SETTLETOP_PID"
fi

# TO DEBUG SettleTop-Server RUN WITH THESE OPTIONS:
# -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=1044
# AND ATTACH TO THE CURRENT HOST, PORT 1044

# Java memory options, default to 512 of heap.
if [ -z "$SETTLETOP_OPTS_MEMORY" ] ; then
    SETTLETOP_OPTS_MEMORY="-Xmx1g"
fi

echo $$ > $SETTLETOP_PID

CLASSPATH=
for i in `ls $SETTLETOP_HOME/lib/*.jar`
do
  CLASSPATH=${CLASSPATH}:${i}
done

CLASSPATH=$CLASSPATH:$SETTLETOP_HOME

exec "$JAVA" $JAVA_OPTS $SETTLETOP_OPTS_MEMORY $JAVA_OPTS_SCRIPT \
    -cp "${SETTLETOP_HOME}:${CLASSPATH}" \
    $*  com.settletop.server.boot.Server "[version]"
    
    