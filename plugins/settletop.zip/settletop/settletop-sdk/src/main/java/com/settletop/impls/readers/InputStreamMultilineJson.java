package com.settletop.impls.readers;

import java.io.InputStream;
import java.util.Scanner;

import com.settletop.json.JsonException;
import com.settletop.json.JsonObject;
import com.settletop.utils.Lang;

public class InputStreamMultilineJson implements MultilineJson {

	private Scanner scanner;
	
	private long lineLength;
	private long length;
	
	public InputStreamMultilineJson (InputStream stream) {
		this.scanner = new Scanner (stream);
	}
	
	public boolean hasNext () {
		return scanner.hasNextLine ();
	}

	public JsonObject next () {
		String line = scanner.nextLine ();
		if (Lang.isNullOrEmpty (line)) {
			return JsonObject.Blank;
		}
		this.lineLength = line.length ();
		this.length += this.lineLength;
		JsonObject object;
		try {
			object = new JsonObject (line);
		} catch (JsonException e) {
			throw new RuntimeException (e);
		}
		object.shrink ();
		return object;
	}
	
	public long getLength () {
		return length;
	}
	
	public long getLineLength () {
		return lineLength;
	}
	
}
