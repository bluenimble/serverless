package com.settletop;

import java.io.IOException;
import java.io.InputStream;

public interface ApiRequestBodyReader {
	
	Object read (InputStream stream) throws IOException;
	
}
