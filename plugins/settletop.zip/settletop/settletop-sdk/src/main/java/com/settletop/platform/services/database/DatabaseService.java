package com.settletop.platform.services.database;

import com.settletop.platform.services.PlatformService;

public interface DatabaseService extends PlatformService {

	Database 	get (boolean trx);
	
}
