package com.settletop.impls.readers;

import java.io.IOException;
import java.io.InputStream;

import com.settletop.ApiRequestBodyReader;
import com.settletop.utils.IOUtils;

public class ApiRequestBodyTextReader implements ApiRequestBodyReader {

	@Override
	public Object read (InputStream stream) throws IOException {
		try {
			return IOUtils.toString (stream);
		} catch (Exception ex) {
			throw new IOException (ex.getMessage (), ex);
		}
	}


}
