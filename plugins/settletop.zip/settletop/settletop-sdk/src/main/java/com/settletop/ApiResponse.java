package com.settletop;

import java.io.InputStream;

import com.settletop.json.JsonObject;

public interface ApiResponse {
	
	void 			writeHeader 		(String name, String value);
	
	void 			writeText 			(String text);
	void 			writeHtml 			(String html);
	void 			writeJson 			(JsonObject json);
	void 			writeBytes 			(byte [] bytes);
	void 			writeStream 		(int code, InputStream stream, long size);
	
	void			writeError			(int code, String message);
	
}
