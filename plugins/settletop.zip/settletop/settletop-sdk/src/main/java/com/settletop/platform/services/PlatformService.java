package com.settletop.platform.services;

import com.settletop.json.JsonObject;
import com.settletop.server.ApiServer;

public interface PlatformService {

	void initialize (ApiServer server, JsonObject spec);
	
}
