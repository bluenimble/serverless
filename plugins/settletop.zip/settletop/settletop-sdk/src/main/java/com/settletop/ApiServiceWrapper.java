package com.settletop;

import com.settletop.json.JsonObject;

public class ApiServiceWrapper {

	private ApiService 	service;
	private JsonObject 	specification;
	
	public ApiServiceWrapper (JsonObject specification, ApiService service) {
		this.specification = specification;
		this.service = service;
	}
	
	public ApiService getService () {
		return service;
	}
	
	public JsonObject getSpecification () {
		return specification;
	}
	
}
