package com.settletop.platform.security;

public class SecurityAgentException extends Exception {

	private static final long serialVersionUID = 3526264775480364319L;
	
	private int code = 401;
	
	public SecurityAgentException (int code, String message) {
		super (message);
		this.code = code;
	}
	
	public SecurityAgentException (String message) {
		this (401, message);
	}

	public SecurityAgentException (Throwable th) {
		super (th);
	}

	public SecurityAgentException (String message, Throwable th) {
		super (message, th);
	}
	
	public int getCode () {
		return code;
	}

}
