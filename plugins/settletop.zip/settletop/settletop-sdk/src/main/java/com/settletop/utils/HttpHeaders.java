package com.settletop.utils;

public interface HttpHeaders {
	
	String Accpt 				= "ACCEPT";
	String AcceptEncoding 		= "Accept-Encoding";
	String AcceptCharset 		= "Accept-Charset";
	String Authorization 		= "Authorization";
	String ContentEncoding 		= "Content-Encoding";
	String CacheControl 		= "Cache-Control";
	String ContentDisposition 	= "Content-Disposition";
	String ContentType 			= "Content-Type";
	String ContentLength 		= "Content-Length";
	String Connection			= "Connection";
	String IfModifiedSince 		= "If-Modified-Since";
	String LastModified 		= "Last-Modified";
	String Pragma 				= "Pragma";
	String Public 				= "public";
	String MaxAge 				= "max-age";
	String UserAgent 			= "User-Agent";
	String SetCookie 			= "Set-Cookie";
	String Cookie 				= "Cookie";
	String Server 				= "Server";
	
}