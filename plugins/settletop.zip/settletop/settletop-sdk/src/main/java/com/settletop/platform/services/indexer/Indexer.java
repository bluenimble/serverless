package com.settletop.platform.services.indexer;

import java.util.List;

import com.settletop.json.JsonObject;

public interface Indexer {
	
	void 		newIndex 		(String index, JsonObject schema);
	
	void 		create 			(String index, JsonObject object);
	JsonObject 	get 			(String index, String id, JsonObject fields);
	
	void 		update 			(String index, String id, JsonObject object);
	void 		updateByQuery 	(String index, JsonObject query, JsonObject update);
	
	void 		delete 			(String index, String id);
	void 		deleteByQuery 	(String index, JsonObject query);
	
	JsonObject 	search 			(String index, JsonObject query);
	
	void 		load 			(String index, List<JsonObject> documents);
	
}
