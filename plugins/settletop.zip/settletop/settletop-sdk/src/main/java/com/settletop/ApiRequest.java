package com.settletop;

import java.util.Set;

public interface ApiRequest {
	
	interface Verbs {
		String Get 		= "GET";
		String Post 	= "POST";
		String Put 		= "PUT";
		String Delete 	= "DELETE";
		String Patch	= "PATCH";
	}
	
	enum Channel {
		Http,
		Container
	}
	
	Channel 		getChannel 			();
	
	String 			getVerb 			();
	String 			getPath 			();
	String 			getContentType		();
	
	Set<String> 	enumerateParameters ();
	Set<String> 	enumerateHeaders 	();
    
	void			addParameter 		(String name, Object value);
	Object			getParameter		(String name);

	String			getHeader			(String name);
	
	Object			getBody				();
	
	void			recycle				();
	
}
