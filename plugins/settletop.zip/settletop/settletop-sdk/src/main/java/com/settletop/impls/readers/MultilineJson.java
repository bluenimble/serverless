package com.settletop.impls.readers;

import com.settletop.json.JsonObject;

public interface MultilineJson {

	boolean 	hasNext ();
	JsonObject 	next ();
	
	long 	getLength ();
	long 	getLineLength ();
	
}
