package com.settletop.impls.readers;

import java.io.IOException;
import java.io.InputStream;

import com.settletop.ApiRequestBodyReader;
import com.settletop.utils.Json;

public class ApiRequestBodyJsonReader implements ApiRequestBodyReader {

	@Override
	public Object read (InputStream stream) throws IOException {
		try {
			return Json.load (stream);
		} catch (Exception ex) {
			throw new IOException (ex);
		}
	}

}
