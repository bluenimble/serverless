package com.settletop.platform.services.database;

import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.Releasable;

public interface Database extends Releasable {
	
	void 				create 		(String collection, JsonObject object);
	void 				update 		(String collection, Object id, JsonObject object);
	int 				delete 		(String collection, Object id);

	JsonObject 			get 		(String collection, Object id);
	JsonObject 			findOne 	(String collection, JsonObject query);
	JsonArray 			find 		(String collection, JsonObject query);
	
	void 				commit 		();
	void 				rollback 	();
	
}
