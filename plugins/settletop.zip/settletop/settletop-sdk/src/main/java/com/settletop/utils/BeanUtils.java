package com.settletop.utils;

import java.lang.reflect.Constructor;

public class BeanUtils {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object create (String className, ClassLoader classLoader) throws Exception {
		if (classLoader == null) {
			classLoader = Thread.currentThread ().getContextClassLoader ();
		}
		Class clazz = classLoader.loadClass (className);
		Constructor constructor = clazz.getConstructor ();
		return constructor.newInstance ();
	}
	
}
