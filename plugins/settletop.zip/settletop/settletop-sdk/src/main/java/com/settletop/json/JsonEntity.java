package com.settletop.json;

import java.io.Serializable;

public interface JsonEntity extends Serializable {
	
	public static final String 		FIND_SEP 		= "/";
	
	public static final String 		PRINT_AS_ARRAY 	= "PrintAsArray";
	
	JsonEntity 	set (String name, Object value);
	void 		clear ();
}
