package com.settletop;

import java.io.IOException;

public interface ApiServiceOutput {
	
	void 	writeTo (ApiResponse response) throws IOException;
    
}
