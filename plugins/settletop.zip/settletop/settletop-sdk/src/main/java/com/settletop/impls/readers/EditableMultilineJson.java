package com.settletop.impls.readers;

import java.util.ArrayList;
import java.util.List;

import com.settletop.json.JsonObject;

public class EditableMultilineJson implements MultilineJson {

	private int 				cursor = 0;
	private JsonRecord 			current;
	
	private long 				length;
	private List<JsonRecord> 	records = new ArrayList<JsonRecord>();
	
	@Override
	public boolean hasNext () {
		return cursor < records.size ();
	}

	@Override
	public JsonObject next () {
		current = records.get (cursor);
		cursor++;
		length += current.length; 
		return current.object;
	}
	
	@Override
	public long getLength () {
		return length;
	}
	
	@Override
	public long getLineLength () {
		if (current == null) {
			return 0;
		}
		return current.length;
	}
	
	public void add (JsonObject object, long length) {
		if (object == null) {
			return;
		}
		object.shrink ();
		records.add (new JsonRecord (object, length));
	}
	
	class JsonRecord {
		long 		length;
		JsonObject 	object;
		JsonRecord (JsonObject object, long length) {
			this.object	= object;
			this.length = length;
		}
	}
	
}
