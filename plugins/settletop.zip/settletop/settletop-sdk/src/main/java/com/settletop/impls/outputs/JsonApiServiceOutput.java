package com.settletop.impls.outputs;

import java.io.IOException;

import com.settletop.ApiResponse;
import com.settletop.ApiServiceOutput;
import com.settletop.json.JsonObject;

public class JsonApiServiceOutput implements ApiServiceOutput {

	private JsonObject data;
	
	public JsonApiServiceOutput (JsonObject data) {
		this.data = data;
	}
	
	@Override
	public void writeTo (ApiResponse response) throws IOException {
		response.writeJson (data);
	}

}
