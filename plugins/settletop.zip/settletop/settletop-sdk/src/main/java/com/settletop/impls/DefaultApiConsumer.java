package com.settletop.impls;

import com.settletop.ApiConsumer;
import com.settletop.json.JsonObject;
import com.settletop.utils.Json;

public class DefaultApiConsumer implements ApiConsumer {

	private JsonObject data;
	
	public DefaultApiConsumer (JsonObject data) {
		this.data = data;
	}

	@Override
	public Object get (String... accessors) {
		return Json.find (data, accessors);
	}

	@Override
	public JsonObject toJson () {
		return data;
	}
	
}
