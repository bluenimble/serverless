package com.settletop;

public class ApiServiceExecutionException extends Exception {

	private static final long serialVersionUID = 3526264775480364319L;
	
	private int code;
	
	public ApiServiceExecutionException (int code, String message) {
		super (message);
		this.code = code;
	}
	
	public ApiServiceExecutionException (String message) {
		this (200, message);
	}

	public ApiServiceExecutionException (Throwable th) {
		super (th);
	}

	public ApiServiceExecutionException (String message, Throwable th) {
		super (message, th);
	}
	
	public int getCode () {
		return code;
	}

}
