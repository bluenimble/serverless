package com.settletop.platform.services;

public interface Releasable {

	void release (boolean success);
	
}
