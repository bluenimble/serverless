package com.settletop.impls;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.settletop.ApiRequest;
import com.settletop.utils.HttpHeaders;

public abstract class AbstractApiRequest implements ApiRequest {
	
	private static final Set<String> EmptySet = Collections.<String>emptySet();
	
	protected Map<String, String> headers = new HashMap<String, String>();
	protected Map<String, Object> parameters;
	
	protected Object body;
	
	@Override
	public Set<String> enumerateParameters () {
		if (parameters == null) {
			return EmptySet;
		}
		return parameters.keySet ();
	}

	@Override
	public Set<String> enumerateHeaders () {
		if (headers == null) {
			return EmptySet;
		}
		return headers.keySet ();
	}

	@Override
	public Object getParameter (String name) {
		if (name == null) {
			return null;
		}
		if (parameters == null) {
			return null;
		}
		return parameters.get (name);
	}

	@Override
	public void addParameter (String name, Object value) {
		if (name == null) {
			return;
		}
		if (parameters == null) {
			parameters = new HashMap<String, Object>();
		}
		parameters.put (name, value);
	}

	@Override
	public String getHeader (String name) {
		if (name == null) {
			return null;
		}
		return headers.get (name.toUpperCase ());
	}

	@Override
	public Object getBody () {
		return this.body;
	}
	
	@Override
	public String getContentType () {
		return this.getHeader (HttpHeaders.ContentType);
	}
	
	@Override
	public void recycle () {
		if (headers != null) {
			headers.clear ();
			headers = null;
		}
		if (parameters != null) {
			parameters.clear ();
			parameters = null;
		}
	}
	
}
