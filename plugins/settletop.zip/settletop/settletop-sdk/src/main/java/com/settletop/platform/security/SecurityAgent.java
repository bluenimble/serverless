package com.settletop.platform.security;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiServiceRegistry;
import com.settletop.json.JsonObject;
import com.settletop.server.ApiServer;

public interface SecurityAgent {
	
	interface Schemes {
		String TOKEN 	= "TOKEN";
		String NONE 	= "NONE";
	}

	void 		initialize 	(ApiServer server, JsonObject spec);
	
	JsonObject 	issueToken 	(JsonObject payload, int ageInMinutes);
	
	ApiConsumer check 		(ApiContext context, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification)
					throws SecurityAgentException;
	
}
