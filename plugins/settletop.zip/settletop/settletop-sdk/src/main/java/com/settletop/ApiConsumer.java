package com.settletop;

import com.settletop.json.JsonObject;

public interface ApiConsumer {
	
	String Anonymous = "Anonymous";
	
	interface Fields {
		String Tenant 		= "tenant";
		String Workspace 	= "workspace";
		String Role 		= "role";
	}
	
	Object 		get (String... accessors);
	
	JsonObject	toJson ();
    
}
