package com.settletop;

public interface ApiServiceRegistry {
	
	interface Service {
		String Id			= "id";
		String Endpoint		= "endpoint";
		String Verb			= "verb";
		String Spi			= "spi";
		String Response		= "response";
	}
	
	interface Defaults {
		String Verb = "GET";
	}
	
	ApiServiceWrapper lookup 			(String id);
	ApiServiceWrapper lookup 			(String verb, String path);
	
}
