package com.settletop;

import com.settletop.json.JsonObject;

public interface ApiService {
	
	interface Spec {
		String Runtime 	= "runtime";
		String Security = "security";
			String Authorization 	= "authorization";
				String Scheme 		= "scheme";
				String Rights		= "rights";
	}
	
	ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException;
    
}
