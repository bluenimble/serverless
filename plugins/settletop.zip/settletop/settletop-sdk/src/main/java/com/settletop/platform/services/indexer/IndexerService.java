package com.settletop.platform.services.indexer;

import com.settletop.platform.services.PlatformService;

public interface IndexerService extends PlatformService {
	
	Indexer get ();
	
}
