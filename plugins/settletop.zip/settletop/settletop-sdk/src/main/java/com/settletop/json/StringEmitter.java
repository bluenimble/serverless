package com.settletop.json;

public class StringEmitter extends AbstractEmitter {
	
	private StringBuilder 	buff;
	
	public StringEmitter (StringBuilder buff, boolean cast) {
		super ();
		this.buff = buff;
		this.cast = cast;
	}

	public JsonEmitter write (String text) {
		buff.append (text);
		return this;
	} 
	
}
