package com.settletop.impls;

public class ContainerApiRequest extends AbstractApiRequest {
	
	private String verb;
	private String path;

	public ContainerApiRequest (String verb, String path) {
		this.verb = verb;
		this.path = path;
	}

	@Override
	public String getVerb () {
		return verb;
	}

	@Override
	public String getPath () {
		return path;
	}

	@Override
	public void recycle() {
		super.recycle ();
	}

	@Override
	public Channel getChannel () {
		return Channel.Container;
	}

	public void removeParameter (String name) {
		this.parameters.remove (name);
	}
	
	public void addHeader (String name, String value) {
		this.headers.put (name, value);
	}
	public void removeHeader (String name) {
		this.headers.remove (name);
	}
	
	public void setBody (Object body) {
		this.body = body;
	}
	
}
