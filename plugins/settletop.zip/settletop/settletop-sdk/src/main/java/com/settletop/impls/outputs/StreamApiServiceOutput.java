package com.settletop.impls.outputs;

import java.io.IOException;
import java.io.InputStream;

import com.settletop.ApiResponse;
import com.settletop.ApiServiceOutput;

public class StreamApiServiceOutput implements ApiServiceOutput {

	private InputStream data;
	private long 		size;
	private int 		code = 200;
	
	public StreamApiServiceOutput (int code, InputStream data, long size) {
		this.code = code;
		this.data = data;
		this.size = size;
	}
	public StreamApiServiceOutput (InputStream data, long size) {
		this.data = data;
		this.size = size;
	}
	
	@Override
	public void writeTo (ApiResponse response) throws IOException {
		response.writeStream (code, data, size);
	}

}
