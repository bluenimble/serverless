package com.settletop.platform.security;

import com.settletop.json.JsonObject;
import com.settletop.server.ApiServer;

public interface SecretsProvider {

	void 		initialize 	(ApiServer server, JsonObject spec);
	
	JsonObject 	lookup 		(String path);
	
}
