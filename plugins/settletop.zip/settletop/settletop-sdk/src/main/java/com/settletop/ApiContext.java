package com.settletop;

import com.settletop.platform.security.SecurityAgent;
import com.settletop.platform.services.database.Database;
import com.settletop.platform.services.indexer.Indexer;

public interface ApiContext {
	
	Database 			getDatabase 		(String name, boolean trx);
	Indexer 			getIndexer  		(String name);
	SecurityAgent 		getSecurityAgent  	();
	
	ApiServiceOutput	execute 			(ApiConsumer consumer, ApiRequest request, ApiResponse response)
							throws ApiServiceExecutionException;
    
}
