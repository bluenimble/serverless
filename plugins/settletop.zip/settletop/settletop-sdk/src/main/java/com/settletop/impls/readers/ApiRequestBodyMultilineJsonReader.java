package com.settletop.impls.readers;

import java.io.IOException;
import java.io.InputStream;

import com.settletop.ApiRequestBodyReader;

public class ApiRequestBodyMultilineJsonReader implements ApiRequestBodyReader {
	
	@Override
	public Object read (InputStream stream) throws IOException {
		return new InputStreamMultilineJson (stream);
	}

}
