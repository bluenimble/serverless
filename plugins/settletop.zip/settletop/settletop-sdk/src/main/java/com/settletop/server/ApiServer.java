package com.settletop.server;

import java.io.File;

import com.settletop.ApiServiceRegistry;
import com.settletop.platform.security.SecretsProvider;
import com.settletop.platform.security.SecurityAgent;

public interface ApiServer {

	void start 			() throws StartApiServerException;
	void stop 			();
	
	File 				getHome 			();
	
	Object 				getPlatformService 	(String name);

	SecretsProvider 	getSecretsProvider 	();
	SecurityAgent 		getSecurityAgent 	();
	
	ApiServiceRegistry 	getServiceRegistry 	();
	
}
