package com.settletop.impls.outputs;

import java.io.IOException;

import com.settletop.ApiResponse;
import com.settletop.ApiServiceOutput;

public class TextApiServiceOutput implements ApiServiceOutput {

	private String data;
	
	public TextApiServiceOutput (String data) {
		this.data = data;
	}
	
	@Override
	public void writeTo (ApiResponse response) throws IOException {
		response.writeText (data);
	}

}
