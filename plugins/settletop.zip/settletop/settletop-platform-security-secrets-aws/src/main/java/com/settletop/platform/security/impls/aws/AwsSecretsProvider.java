package com.settletop.platform.security.impls.aws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.amazonaws.services.secretsmanager.model.InvalidParameterException;
import com.amazonaws.services.secretsmanager.model.InvalidRequestException;
import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import com.settletop.json.JsonException;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecretsProvider;
import com.settletop.server.ApiServer;
import com.settletop.utils.Json;

public class AwsSecretsProvider implements SecretsProvider {
	
	private static final Logger Logger = LoggerFactory.getLogger (AwsSecretsProvider.class);

	interface Spec {
		String Region = "region";
	}
	
	private JsonObject 	spec;
	private String 		endpoint;
	
	@Override
	public void initialize (ApiServer server, JsonObject spec) {
		this.spec = spec;
		this.endpoint = "secretsmanager." + Json.getString (spec, Spec.Region) + ".amazonaws.com";
	}

	@Override
	public JsonObject lookup (String path) {
        AwsClientBuilder.EndpointConfiguration config = new AwsClientBuilder.EndpointConfiguration (endpoint, Json.getString (this.spec, Spec.Region));
        AWSSecretsManagerClientBuilder clientBuilder = AWSSecretsManagerClientBuilder.standard ();
        clientBuilder.setEndpointConfiguration (config);
        AWSSecretsManager client = clientBuilder.build ();
        
        GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId (path);
        GetSecretValueResult getSecretValueResponse = null;
        try {
            getSecretValueResponse = client.getSecretValue(getSecretValueRequest);
        } catch (ResourceNotFoundException e) {
        	Logger.error ("The requested secret " + path + " was not found");
        } catch (InvalidRequestException e) {
        	Logger.error ("The request was rejected due to an InvalidRequestException - " + e.getMessage ());
        } catch (InvalidParameterException e) {
        	Logger.error ("The request had an InvalidParameterException " + e.getMessage ());
        }

        if (getSecretValueResponse == null) {
            return null;
        }
        
        String value = getSecretValueResponse.getSecretString ();

        Logger.debug ("Secret Name : " + path + "\t Secret Value : " + value + "\n");

        try {
			return new JsonObject (value);
		} catch (JsonException e) {
			Logger.error ("Can't parse server value as Json ");
		}
        return null;
	}

}
