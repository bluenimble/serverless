package com.settletop.platform.services.database.impls.mongodb;

import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadConcern;
import com.mongodb.WriteConcern;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.database.Database;
import com.settletop.platform.services.database.DatabaseService;
import com.settletop.server.ApiServer;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class MongoDbService implements DatabaseService {
	
	private static final String DefaultDriver 		= "mongodb+srv";
	
	private static final String DefaultWriteConcern = "MAJORITY";
	private static final String DefaultReadConcern 	= "MAJORITY";
	
	interface Spec {
		String Host 	= "host";
		String Database = "database";
		String Driver 	= "driver";
		
		String SSL 		= "ssl";
		String MaxConnections
						= "maxConnections";
		String ThreadsAllowedToBlock
						= "threadsAllowedToBlock";
		String MaxWaitTime
						= "maxWaitTime";
		String ConnectTimeout 	
						= "connectTimeout"; 
		String SocketTimeout
						= "socketTimeout";
		
		String WriteConcern
						= "writeConcern";
		String ReadConcern
						= "readConcern";
		
		String RetryWrites
						= "retryWrites";
		
		String Secrets 	= "secrets";
			String User 	= "user";
			String Password = "password";
			
		String AllowProprietaryAccess
						= "allowProprietaryAccess";
		
		String CaseSensitive
						= "caseSensitive";
	}

	private JsonObject spec;
	
	private CodecRegistry 	codecRegistry;
	private MongoClient		client;
	
	@Override
	public void initialize (ApiServer server, JsonObject spec) {
		this.spec = spec;
		codecRegistry = CodecRegistries.fromRegistries (
			MongoClient.getDefaultCodecRegistry (), 
			CodecRegistries.fromProviders (PojoCodecProvider.builder ().automatic (true).build ())
		);
		createClient (server, spec);
	}

	@Override
	public Database get (boolean trx) {
		return new MongoDbDatabase (client, client.getDatabase (Json.getString (this.spec, Spec.Database)), trx);
	}
	
	private void createClient (ApiServer server, JsonObject spec) {
		String host = Json.getString (spec, Spec.Host);
		
		String driver = Json.getString (spec, Spec.Driver, DefaultDriver);
		
		String swc = Json.getString (spec, Spec.WriteConcern, DefaultWriteConcern);
		WriteConcern wc = null;
		try {
			wc = (WriteConcern)WriteConcern.class.getField (swc).get (null);
		} catch (Exception e) {
			wc = WriteConcern.MAJORITY;
		}
		
		String src = Json.getString (spec, Spec.ReadConcern, DefaultReadConcern);
		ReadConcern rc = null;
		try {
			rc = (ReadConcern)ReadConcern.class.getField (src).get (null);
		} catch (Exception e) {
			rc = ReadConcern.MAJORITY;
		}

		MongoClientOptions.Builder optionsBuilder = 
				MongoClientOptions.builder ()
					.cursorFinalizerEnabled (false)
					.readConcern (rc)
					.writeConcern (wc)
					.retryWrites (Json.getBoolean (spec, Spec.RetryWrites, true))
					.codecRegistry (codecRegistry)
					.sslEnabled (Json.getBoolean (spec, Spec.SSL, false))
					.connectionsPerHost (Json.getInteger (spec, Spec.MaxConnections, 10))
					.maxWaitTime (Json.getInteger (spec, Spec.MaxWaitTime, 1000))
					.connectTimeout (Json.getInteger (spec, Spec.ConnectTimeout, 10000))
					.socketTimeout (Json.getInteger (spec, Spec.SocketTimeout, 0));
		
		String credentials = null;
		
		JsonObject secrets = server.getSecretsProvider ().lookup (Json.getString (spec, Spec.Secrets));
		if (!Json.isNullOrEmpty (secrets)) {
			credentials = Json.getString (secrets, Spec.User) + Lang.COLON + Json.getString (secrets, Spec.Password);
		}
		
		MongoClientURI uri = new MongoClientURI (
			driver + "://" + (credentials == null ? Lang.BLANK : credentials + Lang.AT) + host,
			optionsBuilder
		);
				
		this.client = new MongoClient (uri);
	}
	
}
