package com.settletop.platform.services.database.impls.mongodb;

import static com.mongodb.client.model.Filters.eq;

import java.util.Date;
import java.util.Iterator;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.TransactionOptions;
import com.mongodb.WriteConcern;
import com.mongodb.client.ClientSession;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.result.DeleteResult;
import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.database.Database;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class MongoDbDatabase implements Database {
	
	private static final Logger Logger = LoggerFactory.getLogger (MongoDbDatabase.class);
	
	interface Internal {
		String Id = "_id";
	}
	
	interface Fields {
		String Id 			= "id";
		String Timestamp 	= "timestamp";
	}
	
	interface Dsl {
		String Set 			= "set";
		String Unset 		= "unset";
	}
	
	private MongoDatabase 	mdb;
	private ClientSession 	session;
	
	public MongoDbDatabase (MongoClient client, MongoDatabase mdb, boolean trx) {
		this.mdb = mdb;
		if (!trx) {
			return;
		}
		session = client.startSession ();
		session.startTransaction (TransactionOptions.builder ().writeConcern (WriteConcern.ACKNOWLEDGED).build ());
	}
	
	@Override
	public void create (String collection, JsonObject object) {
		if (Lang.isNullOrEmpty (collection)) {
			throw new RuntimeException ("Collection is required");
		}
		if (Json.isNullOrEmpty (object)) {
			throw new RuntimeException ("Object payload is required");
		}
		MongoCollection<Document> mc = this.getCollection (collection);
		if (mc == null) {
			throw new RuntimeException ("Collection not found");
		}
		Document document = new Document ();
		document.append (Fields.Timestamp, new Date ());
		Iterator<String> keys = object.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			document.append (key, object.get (key));
		}
		if (this.session == null) {
			mc.insertOne (document);
		} else {
			mc.insertOne (this.session, document);
		}
		object.set (Fields.Id, document.get (Internal.Id).toString ());
		object.set (Fields.Timestamp, document.get (Fields.Timestamp));
	}
	
	@Override
	public JsonObject get (String collection, Object id) {
		if (Lang.isNullOrEmpty (collection)) {
			throw new RuntimeException ("Collection is required");
		}
		if (id == null) {
			throw new RuntimeException ("Object Id is required");
		}
		Logger.debug ("Get Record by id " + collection + " [" + id + "]");
		MongoCollection<Document> mc = this.getCollection (collection);
		if (mc == null) {
			Logger.debug ("Collection " + collection + " Not found");
			throw new RuntimeException ("Collection not found");
		}
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		Document document = null;
		if (this.session == null) {
			document = mc.find (eq (Internal.Id, _id)).first ();
		} else {
			document = mc.find (this.session, eq (Internal.Id, _id)).first ();
		}
		return toJson (document);
	}
	
	@Override
	public void update (String collection, Object id, JsonObject object) {
		if (Lang.isNullOrEmpty (collection)) {
			throw new RuntimeException ("Collection is required");
		}
		if (id == null) {
			throw new RuntimeException ("Object Id is required");
		}
		if (Json.isNullOrEmpty (object)) {
			throw new RuntimeException ("Update payload is required");
		}
		MongoCollection<Document> mc = this.getCollection (collection);
		if (mc == null) {
			throw new RuntimeException ("Collection not found");
		}
		
		Document update = new Document ();
		if (object.containsKey (Dsl.Set)) {
			Document set = new Document ();
			update.put (Dsl.Set, set);
			copy (Json.getObject (object, Dsl.Set), set);
		}
		if (object.containsKey (Dsl.Unset)) {
			Document unset = new Document ();
			update.put (Dsl.Unset, unset);
			copy (Json.getObject (object, Dsl.Unset), unset);
		}
		
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		if (this.session == null) {
			mc.updateOne (eq (Internal.Id, _id), update);
		} else {
			mc.updateOne (this.session, eq (Internal.Id, _id), update);
		}
	}
	
	@Override
	public int delete (String collection, Object id) {
		if (Lang.isNullOrEmpty (collection)) {
			throw new RuntimeException ("Collection is required");
		}
		if (id == null) {
			throw new RuntimeException ("Object Id is required");
		}
		MongoCollection<Document> mc = this.getCollection (collection);
		if (mc == null) {
			throw new RuntimeException ("Collection not found");
		}
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		
		DeleteResult result = null;
		
		if (session == null) {
			result = mc.deleteOne (eq (Internal.Id, _id));
		} else {
			result = mc.deleteOne (session, eq (Internal.Id, _id));
		}
		
		return (int)result.getDeletedCount ();
	}
	
	@Override
	public JsonObject findOne (String collection, JsonObject query) {
		FindIterable<Document> cursor = _find (collection, query, 1);
		return toJson (cursor.first ());
	}
	
	@Override
	public JsonArray find (String collection, JsonObject query) {
		return toJsonArray (_find (collection, query, 0));
	}
	
	@Override
	public void commit () {
		if (this.session == null) {
			return;
		}
		this.session.commitTransaction ();
	}

	@Override
	public void rollback () {
		if (this.session == null) {
			return;
		}
		this.session.abortTransaction ();
	}

	@Override
	public void release (boolean success) {
		if (session == null) {
			return;
		}
		
		if (success) {
			this.commit ();
		} else {
			this.rollback ();
		}
		
		Logger.debug ("Releasing database instance " + mdb);
		
		session.close ();
	}
	
	private FindIterable<Document> _find (String collection, JsonObject query, int count) {
		if (Lang.isNullOrEmpty (collection)) {
			throw new RuntimeException ("Collection is required");
		}
		if (query == null) {
			query = new JsonObject ();
		}
		
		MongoCollection<Document> mc = this.getCollection (collection);
		if (mc == null) {
			throw new RuntimeException ("Collection not found");
		}
		
		BasicDBObject mdbq = new BasicDBObject (query);
		
		FindIterable<Document> cursor = mc.find (mdbq);
		if (count > 0) {
			cursor.limit (count);
		}
		
		return cursor;
	}
	
	private MongoCollection<Document> getCollection (String collection) {
		return mdb.getCollection (collection.toUpperCase ());
	}
	
	private JsonObject toJson (Document document) {
		if (document == null) {
			return null;
		}
		JsonObject object = new JsonObject ();
		Iterator<String> fields = document.keySet ().iterator ();
		while (fields.hasNext ()) {
			String field = fields.next ();
			object.set (field.equals (Internal.Id) ? Fields.Id : field, document.get (field));
		}
		return object;
	}
	
	private void copy (JsonObject object, Document document) {
		Iterator<String> keys = object.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			document.append (key, object.get (key));
		}
	}
	
	private JsonArray toJsonArray (MongoIterable<Document> documents) {
		if (documents == null) {
			return JsonArray.Blank;
		}
		JsonArray array = new JsonArray ();
		for (Document document : documents) {
			array.add (toJson (document));
		}
		return array;
	}
	
}
