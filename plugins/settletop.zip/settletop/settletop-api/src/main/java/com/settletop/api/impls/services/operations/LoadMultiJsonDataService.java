package com.settletop.api.impls.services.operations;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.datasets.CreateDataSetService;
import com.settletop.api.impls.services.operations.LoadJsonDataService.ObjectSpec;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.impls.readers.MultilineJson;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.indexer.Indexer;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class LoadMultiJsonDataService implements ApiService {
	
	private static final Logger Logger = LoggerFactory.getLogger (LoadMultiJsonDataService.class);
	
	interface RuntimeSpec {
		
		String MaxBlockSize = "maxBlockSize";
		
		String Records 		= "records";
		String Commit		= "commit";
		String Query 		= "query";
		String Update 		= "update";
		
	}
	
	interface Defaults {
		long 	MaxSize 	= 4 * 1024 * 1024; // 4 MB
	}
	
	interface HeaderSpec {
		String DataSet = "$DataSet";
	}
	
	interface Output {
		String Count = "count"; 
	}
	
	interface RecordStatus {
		int Created 	= 0;
		int Available 	= 1;
		int Archived 	= 2;
	}
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Object 		applicationId 		= request.getParameter (Parameters.Common.Application);
		Object 		operationId 		= request.getParameter (Parameters.Common.Operation);
		
		JsonObject 	application 		= context.getDatabase (null, false).get (Collections.Application.class.getSimpleName (), applicationId);
		if (application == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Application not found");
		}
		
		JsonObject 	operation 			= context.getDatabase (null, false).get (Collections.Operation.class.getSimpleName (), operationId);
		if (operation == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Operation not found");
		}
		
		if (!Json.find (operation, Collections.Common.Application, Collections.Common.Id).equals (applicationId)) {
			throw new ApiServiceExecutionException (404, "Operation not found (missmatch)");
		}
		
		String oTimestamp = Lang.toString ((Date)operation.get (Collections.Common.Timestamp), Lang.UTC_DATE_FORMAT);
		
		MultilineJson 		payload 		= (MultilineJson)request.getBody ();
		Indexer 			indexer 		= context.getIndexer (null);
		
		Long 				maxBlockLength	= (Long)Json.find (specification, ApiService.Spec.Runtime, RuntimeSpec.MaxBlockSize);
		if (maxBlockLength == null) {
			maxBlockLength = Defaults.MaxSize;
		}
		
		List<JsonObject> 	stack 			= new ArrayList<JsonObject> ();
		String 				dataset 		= null;
		
		long 				count 			= 0;
		long 				blockLength 	= 0;
		
		Set<String>			indexes			= new HashSet<String> ();
		
		while (payload.hasNext ()) {
			JsonObject record = null;
			try {
				// read the record -> either is a header or an actual record
				record = payload.next ();
				if (Json.isNullOrEmpty (record)) {
					continue;
				}

				blockLength += payload.getLineLength ();
				
				String hds = Json.getString (record, HeaderSpec.DataSet);
				
				// Either we've reached the max block length or we've detected a new DataSet
				if (blockLength >= maxBlockLength || hds != null) {
					// keep the size
					int stackSize = stack.size ();
					// index name
					String indexName = dataset == null ? 
						CreateDataSetService.appIndexName (String.valueOf (applicationId)) : 
						CreateDataSetService.appIndexName (dataset);
					// keep the index for later commit
					if (!indexes.contains (indexName)) {
						indexes.add (indexName);
					}
					// load block
					load (indexer, indexName, stack);
					// increment the counter
					count += stackSize;
					// set the dataset
					if (hds != null) {
						dataset = hds;
					}
				}
			} catch (Exception e) {
				Logger.error (Lang.BLANK, e);
				throw new ApiServiceExecutionException (400, "Can not read record data");
			}
			
			JsonObject object = (JsonObject)new JsonObject ()
				.set (ObjectSpec.Id, Lang.oid ())
				.set (ObjectSpec.Timestamp, Lang.toString (new Date (), Lang.UTC_DATE_FORMAT))
				.set (ObjectSpec.Status, RecordStatus.Created)
				.set (
					Collections.Operation.class.getSimpleName ().toLowerCase (), 
					new JsonObject ().set (Collections.Common.Id, operationId).set (Collections.Common.Timestamp, oTimestamp)
				)
				.set (
					Collections.Application.class.getSimpleName ().toLowerCase (), 
					new JsonObject ().set (Collections.Common.Id, applicationId)
				)
				.set (
					Collections.Tenant.class.getSimpleName ().toLowerCase (), 
					new JsonObject ().set (Collections.Common.Id, consumer.get (ApiConsumer.Fields.Tenant))
				)
				.set (ObjectSpec.Record, record);
			
			// append document
			stack.add (object);
		}
		
		// remaining objects
		if (stack.size () > 0) {
			// keep the size
			int stackSize = stack.size ();
			// index name
			String indexName = dataset == null ? 
				CreateDataSetService.appIndexName (String.valueOf (applicationId)) : 
				CreateDataSetService.appIndexName (dataset);
			// keep the index for later commit
			if (!indexes.contains (indexName)) {
				indexes.add (indexName);
			}
			// load block
			load (indexer, indexName, stack);
			// increment the counter
			count += stackSize;
		}
		
		// commit all records in different data sets by setting the status to Available (1)
		for (String index : indexes) {
			indexer.updateByQuery (
				index,
				(JsonObject)Json.find (specification, ApiService.Spec.Runtime, RuntimeSpec.Records, RuntimeSpec.Commit, RuntimeSpec.Query),
				(JsonObject)Json.find (specification, ApiService.Spec.Runtime, RuntimeSpec.Records, RuntimeSpec.Commit, RuntimeSpec.Update)
			);
		}
		
		return new JsonApiServiceOutput ((JsonObject)new JsonObject ().set (Output.Count, count));
	}
	
	private void load (Indexer indexer, String index, List<JsonObject> stack) {
		if (stack.isEmpty ()) {
			return;
		}
		Logger.debug ("Load " + stack.size () + " documents into dataset " + index);
		// load
		indexer.load (index, stack);
		// clear stack
		stack.clear ();
	}

}
