package com.settletop.api.impls.services.utils;

public interface Collections {
	
	interface Common {
		String Id 			= "id";
		String Timestamp 	= "timestamp";
		String Deleted 		= "deleted";
		
		String Application 	= "application";
		String Name 		= "name";
	}

	interface Tenant {
	}
	
	interface Role {
		String Keys 		= "keys";
			String AccessKey 	= "accessKey";
			String SecretKey 	= "secretKey";
		String Token 		= "token";
			String Age 		= "age";
	}
	
	interface Application {
	}
	
	interface DataSet {
		String Application	= "application";
		String Schema		= "schema";
		String Fields		= "fields";
		String FieldName	= "name";
		String FieldType	= "type";
	}
	
	interface Operation {
	}
}
