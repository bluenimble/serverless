package com.settletop.api.impls.services.operations;

import java.util.Date;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.datasets.CreateDataSetService;
import com.settletop.api.impls.services.operations.LoadMultiJsonDataService.RecordStatus;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonObject;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class LoadJsonDataService implements ApiService {
	
	interface ObjectSpec {
		String	Id			= "id";
		String	Timestamp	= "timestamp";
		String 	Status 		= "status";
		String 	Application = "application";
		String 	Operation 	= "operation";
		String 	Record 		= "record";
		String 	DataSet 	= "$DataSet";
	}
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Object 		applicationId 		= request.getParameter (Parameters.Common.Application);
		Object 		operationId 		= request.getParameter (Parameters.Common.Operation);
		
		JsonObject 	application 		= context.getDatabase (null, false).get (Collections.Application.class.getSimpleName (), applicationId);
		if (application == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Application not found");
		}
		
		JsonObject 	operation 			= context.getDatabase (null, false).get (Collections.Operation.class.getSimpleName (), operationId);
		if (operation == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Operation not found");
		}
		
		if (!Json.find (operation, Collections.Common.Application, Collections.Common.Id).equals (applicationId)) {
			throw new ApiServiceExecutionException (404, "Operation not found (missmatch)");
		}
		
		String oTimestamp = Lang.toString ((Date)operation.get (Collections.Common.Timestamp), Lang.UTC_DATE_FORMAT);
		
		JsonObject 	record 		= (JsonObject)request.getBody ();
		String 		datasetId 	= Json.getString (record, ObjectSpec.DataSet);
		record.remove (ObjectSpec.DataSet);
		
		JsonObject object = (JsonObject)new JsonObject ()
			.set (ObjectSpec.Id, Lang.oid ())
			.set (ObjectSpec.Timestamp, Lang.toString (new Date (), Lang.UTC_DATE_FORMAT))
			.set (ObjectSpec.Status, RecordStatus.Created)
			.set (
				Collections.Operation.class.getSimpleName ().toLowerCase (), 
				new JsonObject ().set (Collections.Common.Id, operationId).set (Collections.Common.Timestamp, oTimestamp)
			)
			.set (
				Collections.Application.class.getSimpleName ().toLowerCase (), 
				new JsonObject ().set (Collections.Common.Id, applicationId)
			)
			.set (
				Collections.Tenant.class.getSimpleName ().toLowerCase (), 
				new JsonObject ().set (Collections.Common.Id, consumer.get (ApiConsumer.Fields.Tenant))
			)
			.set (ObjectSpec.Record, record);
		
		// store
		String indexName = datasetId == null ? 
			CreateDataSetService.appIndexName (String.valueOf (applicationId)) : 
			CreateDataSetService.appIndexName (datasetId);
		
		context.getIndexer (null).create (indexName, object);
		
		// clear
		object.remove (ObjectSpec.Record, Collections.Tenant.class.getSimpleName ().toLowerCase ());
		
		return new JsonApiServiceOutput (object);
	}

}
