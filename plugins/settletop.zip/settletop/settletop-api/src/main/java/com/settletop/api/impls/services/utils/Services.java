package com.settletop.api.impls.services.utils;

public interface Services {
	
	String CreateDataSet = "CreateDataSet";
}
