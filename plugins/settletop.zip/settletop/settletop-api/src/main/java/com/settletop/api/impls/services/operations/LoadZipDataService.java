package com.settletop.api.impls.services.operations;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.zip.ZipInputStream;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.ContainerApiRequest;
import com.settletop.impls.readers.EditableMultilineJson;
import com.settletop.json.JsonObject;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.IOUtils;
import com.settletop.utils.Json;

public class LoadZipDataService implements ApiService {
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Object 		applicationId 		= request.getParameter (Parameters.Common.Application);
		Object 		operationId 		= request.getParameter (Parameters.Common.Operation);
		
		JsonObject 	application 		= context.getDatabase (null, false).get (Collections.Application.class.getSimpleName (), applicationId);
		if (application == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Application not found");
		}
		
		JsonObject 	operation 			= context.getDatabase (null, false).get (Collections.Operation.class.getSimpleName (), operationId);
		if (operation == null || Json.getBoolean (application, Collections.Common.Deleted, false)) {
			throw new ApiServiceExecutionException (404, "Operation not found");
		}
		
		if (!Json.find (operation, Collections.Common.Application, Collections.Common.Id).equals (applicationId)) {
			throw new ApiServiceExecutionException (404, "Operation not found (missmatch)");
		}
		
		InputStream body = (InputStream)request.getBody ();
		
		EditableMultilineJson mjs = new EditableMultilineJson ();
		
		try (BufferedInputStream bis = new BufferedInputStream (body);
				ZipInputStream stream = new ZipInputStream (bis);) {
            while ((stream.getNextEntry()) != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream ();
                IOUtils.copy (stream, out);
                String line = new String (out.toByteArray ());
                mjs.add (new JsonObject (line), line.length ());
            }
        } catch (Exception e) {
        	throw new ApiServiceExecutionException (e);
		}
		
		// create the global dataset
		ContainerApiRequest dsr = new ContainerApiRequest (
			ApiRequest.Verbs.Post, 
			"/applications/" + applicationId + "/operations/" + operationId + "/data/mlj"
		);
		
		dsr.addHeader (HttpHeaders.ContentType, ContentTypes.MultiJson);
		dsr.setBody (mjs);
		
		return context.execute (consumer, dsr, response);
	}

}
