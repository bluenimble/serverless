package com.settletop.api.impls.services.datasets;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.utils.Json;

public class CreateDataSetService implements ApiService {
	
	private static final String IndexPrefix = "dataset_";
	private static final String AppPrefix 	= "app_";
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		// create the application
		JsonObject oDataSet = (JsonObject)request.getBody ();
		
		Object applicationId = request.getParameter (Parameters.Common.Application);
		
		// set the owning application
		oDataSet.set (
			Collections.DataSet.Application,
			new JsonObject ().set (Collections.Common.Id, applicationId)
		);
		oDataSet.set (Collections.Common.Deleted, false);
		
		// store into the database
		context.getDatabase (null, true).create (Collections.DataSet.class.getSimpleName (), oDataSet);
		
		// create the data index
		JsonObject schema = Json.getObject (oDataSet, Collections.DataSet.Schema);
		
		Object oUseApplicationIdAsDataSetId = request.getParameter (Parameters.Common.UseApplicationIdAsDataSetId);
		
		Boolean useApplicationIdAsDataSetId = 
			oUseApplicationIdAsDataSetId != null && (Boolean)oUseApplicationIdAsDataSetId && 
			request.getChannel ().equals (ApiRequest.Channel.Container);
		
		String indexName = 
			useApplicationIdAsDataSetId ? 
				IndexPrefix + AppPrefix + applicationId : 
				IndexPrefix + Json.getString (oDataSet, Collections.Common.Id);
		context.getIndexer (null).newIndex (indexName, toElasticSearchMapping (schema));
		
		return new JsonApiServiceOutput (oDataSet);
	}
	
	private JsonObject toElasticSearchMapping (JsonObject schema) {
		JsonArray fields = Json.getArray (schema, Collections.DataSet.Fields);
		if (Json.isNullOrEmpty (fields)) {
			return null;
		}
		JsonObject properties = new JsonObject ();
		for (int i = 0; i < fields.count (); i++) {
			JsonObject field = (JsonObject)fields.get (i);
			field = field.duplicate ();
			properties.put (Json.getString (field, Collections.DataSet.FieldName), field);
			field.remove (Collections.DataSet.FieldName);
		}
		return properties;
	}
	
	public static String dsIndexName (String datasetId) {
		return IndexPrefix + datasetId;
	}
	public static String appIndexName (String applicationId) {
		return IndexPrefix + AppPrefix + applicationId;
	}

}
