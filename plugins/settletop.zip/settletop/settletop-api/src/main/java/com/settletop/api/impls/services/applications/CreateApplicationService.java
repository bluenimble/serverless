package com.settletop.api.impls.services.applications;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.ContainerApiRequest;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.database.Database;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;

public class CreateApplicationService implements ApiService {
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Database db = context.getDatabase (null, true);
		
		// create the application
		JsonObject oApplication = (JsonObject)request.getBody ();
		oApplication.set (Collections.Common.Deleted, false);
		
		db.create (Collections.Application.class.getSimpleName (), oApplication);
		
		// create the global dataset
		ContainerApiRequest dsr = new ContainerApiRequest (
			ApiRequest.Verbs.Post, 
			"/applications/" + Json.getString (oApplication, Collections.Common.Id) + "/datasets"
		);
		
		dsr.addHeader (HttpHeaders.ContentType, ContentTypes.Json);
		dsr.addParameter (Parameters.Common.UseApplicationIdAsDataSetId, true);
		dsr.setBody (new JsonObject ().set ("name", "Default Data Set"));
		
		context.execute (consumer, dsr, response);
		
		return new JsonApiServiceOutput (oApplication);
		
		
	}

}
