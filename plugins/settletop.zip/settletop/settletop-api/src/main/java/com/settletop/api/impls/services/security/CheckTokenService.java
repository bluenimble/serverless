package com.settletop.api.impls.services.security;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecurityAgentException;

public class CheckTokenService implements ApiService {
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		ApiConsumer c;
		try {
			c = context.getSecurityAgent ().check (context, request, response, registry, specification);
		} catch (SecurityAgentException e) {
			throw new ApiServiceExecutionException (e);
		}
		
		return new JsonApiServiceOutput (c.toJson ());
	}

}
