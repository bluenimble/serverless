package com.settletop.api.impls.services.operations;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.database.Database;

public class CreateOperationService implements ApiService {
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Object applicationId = request.getParameter (Parameters.Common.Application);
		
		// set the owning application
		JsonObject oOperation = 
			(JsonObject)new JsonObject ()
				.set (Collections.Common.Deleted, false)
				.set (
					Collections.DataSet.Application,
					new JsonObject ().set (Collections.Common.Id, applicationId)
				);
		
		Database db = context.getDatabase (null, true);
		
		// create the operation
		db.create (Collections.Operation.class.getSimpleName (), oOperation);
		
		return new JsonApiServiceOutput (oOperation);
		
	}

}
