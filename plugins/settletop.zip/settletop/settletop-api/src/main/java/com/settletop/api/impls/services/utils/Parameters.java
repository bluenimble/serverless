package com.settletop.api.impls.services.utils;

public interface Parameters {

	interface Common {
		
		String 	Id 							= "id";
		
		String 	Application 				= "application";
		String 	Operation					= "operation";
		String	DataSet						= "dataset";
		
		String 	UseApplicationIdAsDataSetId 	= "useApplicationIdAsDataSetId";
		
	}
	
}
