package com.settletop.api.impls.services.operations;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Parameters;
import com.settletop.impls.ContainerApiRequest;
import com.settletop.json.JsonObject;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;

public class LoadDataService implements ApiService {
	
	interface Spec {
		String Services = "services";
			String Prefix 	= "prefix";
	}
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		Object 		applicationId 		= request.getParameter (Parameters.Common.Application);
		Object 		operationId 		= request.getParameter (Parameters.Common.Operation);
		
		String 		contentType 		= request.getContentType ();
		
		JsonObject 	proxySpec			= (JsonObject)Json.find (specification, ApiService.Spec.Runtime, Spec.Services, contentType);
		if (Json.isNullOrEmpty (proxySpec)) {
			throw new ApiServiceExecutionException (404, "Proxy - Data load service for " + contentType + " not found");
		}
		// create the global dataset
		ContainerApiRequest dsr = new ContainerApiRequest (
			ApiRequest.Verbs.Post, 
			"/applications/" + applicationId + "/operations/" + operationId + "/data/" + Json.getString (proxySpec, Spec.Prefix)
		);
		
		dsr.addHeader (HttpHeaders.ContentType, contentType);
		dsr.setBody (request.getBody ());
		
		return context.execute (consumer, dsr, response);
	}

}
