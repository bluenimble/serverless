package com.settletop.api.impls.services.security;

import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceExecutionException;
import com.settletop.ApiServiceOutput;
import com.settletop.ApiServiceRegistry;
import com.settletop.api.impls.services.utils.Collections;
import com.settletop.impls.outputs.JsonApiServiceOutput;
import com.settletop.json.JsonObject;
import com.settletop.utils.Encodings;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class CreateTokenUsingKeysService implements ApiService {
	
	private static final String AuthorizationScheme 	= "ST-HMAC-SHA256";
	
	private static final String HMAC_SHA256_ALGORITHM 	= "HmacSHA256";
	
	enum Errors {
		InvalidAuthorizationHeader,
		AuthorizationHeaderNotFound,
		InvalidAccessKey,
		InvalidSignature
	}
	
	interface RequestParameters {
		String AccessKey = "ak";
		String Tenant	 = "tn";
	}
	
	interface QueryFilters {
		String AccessKey = "keys.accessKey";
	}
	
	@Override
	public ApiServiceOutput execute (
		ApiContext context, ApiConsumer consumer, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws ApiServiceExecutionException {
		
		String auth = (String)request.getHeader (HttpHeaders.Authorization);
		
		if (Lang.isNullOrEmpty (auth)) {
			throw new ApiServiceExecutionException (401, Errors.AuthorizationHeaderNotFound.toString ());
		}
		
		String [] pair = Lang.split (auth, Lang.SPACE, true);
		
		if (pair.length < 2) {
			throw new ApiServiceExecutionException (401, Errors.InvalidAuthorizationHeader.toString ());
		}
		
		String rScheme = pair [0];

		if (!rScheme.equals (AuthorizationScheme)) {
			throw new ApiServiceExecutionException (401, Errors.InvalidAuthorizationHeader.toString ());
		}
		
		String signature 	= pair [1];
		String tenant 		= (String)request.getParameter (RequestParameters.Tenant);
		String accessKey 	= (String)request.getParameter (RequestParameters.AccessKey);
		
		JsonObject role = context.getDatabase (null, false)
				.findOne (
					Collections.Role.class.getSimpleName (), 
					(JsonObject)new JsonObject ().set (QueryFilters.AccessKey, accessKey)
				);
		if (role == null) {
			throw new ApiServiceExecutionException (401, Errors.InvalidAccessKey.toString ());
		}
		
		String calculatedSignature = null;
		try {
			calculatedSignature = hmac (
				(String)Json.find (role, Collections.Role.Keys, Collections.Role.SecretKey), 
				request.getPath () + Lang.QMARK + 
				RequestParameters.Tenant + Lang.EQUALS + tenant + Lang.AMP +
				RequestParameters.AccessKey + Lang.EQUALS + accessKey
			);
		} catch (Exception e) {
			throw new ApiServiceExecutionException (401, Errors.InvalidSignature.toString ());
		}
		
		if (!signature.equals (calculatedSignature)) {
			throw new ApiServiceExecutionException (401, Errors.InvalidSignature.toString ());
		}
		
		Integer age = (Integer)Json.find (role, Collections.Role.Token, Collections.Role.Age);
		if (age == null) {
			age = -1;
		}
		
		return new JsonApiServiceOutput (
			context.getSecurityAgent ().issueToken (
				(JsonObject)new JsonObject ()
					.set (
						Collections.Tenant.class.getSimpleName ().toLowerCase (), 
						tenant
					)
					.set (
						Collections.Role.class.getSimpleName ().toLowerCase (), 
						role.get (Collections.Common.Id)
					),
				age
			)
		);
	}

	private static String hmac (String secretKey, String data) throws Exception {
		byte [] secretKeyBytes = secretKey.getBytes (Encodings.UTF8);
		
		Mac mac = Mac.getInstance (HMAC_SHA256_ALGORITHM);
	    mac.init (new SecretKeySpec (secretKeyBytes, HMAC_SHA256_ALGORITHM));
	    
		return new String (Base64.getEncoder ().encode (mac.doFinal (data.getBytes (Encodings.UTF8))), Encodings.UTF8).trim ();
	}

}
