package com.settletop.playground.operations;

import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.json.JsonObject;
import com.settletop.playground.ApiClient;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;

public class CreateOperation extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (CreateOperation.class);
	
	public static void main (String [] args) throws Exception {
		new CreateOperation ().run ();
	}
	
	private static final Object Payload = new JsonObject ().set ("name", "Front-End Application");

	public void run () throws Exception {
		
		String uri = "/applications/63f54406ce9fa83a1f0912de/operations";
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri (uri))
				.header ("Authorization", token ())
	            .header (HttpHeaders.ContentType, ContentTypes.Json)
				.POST (HttpRequest.BodyPublishers.ofString (Payload.toString ()))
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	}
	
}
