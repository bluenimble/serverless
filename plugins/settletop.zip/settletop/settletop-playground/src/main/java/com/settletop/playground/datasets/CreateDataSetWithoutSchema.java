package com.settletop.playground.datasets;

import java.io.File;
import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.playground.ApiClient;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;

public class CreateDataSetWithoutSchema extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (CreateDataSetWithoutSchema.class);
	
	public static void main (String [] args) throws Exception {
		new CreateDataSetWithoutSchema ().run ();
	}
	
	public void run () throws Exception {
		
		String uri = "/applications/63f54406ce9fa83a1f0912de/datasets";
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri (uri))
				.header ("Authorization", token ())
	            .header (HttpHeaders.ContentType, ContentTypes.Json)
				.POST (HttpRequest.BodyPublishers.ofString (Json.load (new File ("files/payloads/datasets/create-dataset-without-schema.json")).toString ()))
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	}
	
}
