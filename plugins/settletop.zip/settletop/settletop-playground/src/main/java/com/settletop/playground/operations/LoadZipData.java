package com.settletop.playground.operations;

import java.io.File;
import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.playground.ApiClient;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;

public class LoadZipData extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (LoadZipData.class);
	
	public static void main (String [] args) throws Exception {
		new LoadZipData ().run ();
	}
	
	public void run () throws Exception {
		
		String uri = "/applications/63f54406ce9fa83a1f0912de/operations/63f5456ace9fa83a1f0912e2/data";
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri (uri))
				.header ("Authorization", token ())
	            .header (HttpHeaders.ContentType, ContentTypes.Stream)
				.POST (HttpRequest.BodyPublishers.ofFile (new File ("files/zip/scans.zip").toPath ()))
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	}
	
}
