package com.settletop.playground;

import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.Random;

import com.settletop.json.JsonException;
import com.settletop.json.JsonObject;
import com.settletop.utils.IOUtils;
import com.settletop.utils.Lang;

public class ApiClient {
	
	public enum ResponseType {
		Json,
		Text,
		Binary
	}
	
	public String token () throws Exception {
		return "Bearer " + IOUtils.toString (new FileInputStream (new File ("token"))).trim ();
	}
	
	protected URI buildUri (String path) {
		URI uri = null;
		try {
			uri = new URI ("http://localhost:9090"+ path);
		} catch (URISyntaxException e) {
			throw new RuntimeException (e);
		}
		return uri;
	}
	
	protected Object send (HttpRequest request, ResponseType responseType) {
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient ().send (request, BodyHandlers.ofString ());
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
		
		int code  = response.statusCode ();
		
		if (code != 200) {
			throw new RuntimeException ("Error " + code);
		}
		
		if (responseType == null) {
			return null;
		}
		
		switch (responseType) {
			case Text:
				return response.body ();
			case Json:
			try {
				return new JsonObject (response.body ());
			} catch (JsonException e) {
				throw new RuntimeException (e);
			}
			default:
				return null;
		}
	}
	
	protected String generateMultilineJson (String [] datasets, int size) {
		
		StringBuilder sb = new StringBuilder ();
		
		JsonObject template = new JsonObject ();
		
		Random random = new Random ();
		
		if (datasets == null || datasets.length == 0) {
			for (int i = 0; i < size; i++) {
				template.set ("path", Lang.random (Lang.RandDigits, 12));
				template.set ("lines", 1 + random.nextInt (5000));
				sb.append (template.toString (0, true) + Lang.ENDLN);
			}
			String payload = sb.toString ();
			sb.setLength (0);
			return payload;
		}
		
		int pack = size / datasets.length;
		
		for (String dataset : datasets) {
			sb.append ("{ \"$DataSet\": \"" + dataset + "\" }" + Lang.ENDLN);
			for (int i = 0; i < pack; i++) {
				template.set ("path", Lang.random (Lang.RandDigits, 12));
				template.set ("lines", 1 + random.nextInt (5000));
				sb.append (template.toString (0, true) + Lang.ENDLN);
			}
		}
		
		String payload = sb.toString ();
		sb.setLength (0);
		
		return payload;
		
	}
	
}
