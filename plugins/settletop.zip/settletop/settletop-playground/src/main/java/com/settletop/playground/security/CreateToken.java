package com.settletop.playground.security;

import java.net.http.HttpRequest;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.playground.ApiClient;
import com.settletop.utils.Encodings;

public class CreateToken extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (CreateToken.class);
	
	private static final String HMAC_SHA256_ALGORITHM 	= "HmacSHA256";
	
	public static void main (String [] args) throws Exception {
		new CreateToken ().run ();
	}

	public void run () throws Exception {
		
		String uri = "/security/keys/token?tn=63f3aa1d89425bcf914da1b9&ak=BYRMHCKJJUF9UJW4TEIRTTEJ9BU1UE";
		
		String signature = sign (uri, "W4fm6yb3DCq8696B/3XcUbD7L3eTnsvmrfZVIC5Z");
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri (uri))
				.header ("Authorization", "ST-HMAC-SHA256 " + signature)
				.POST (HttpRequest.BodyPublishers.noBody ())
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	} 
	
	private String sign (String uri, String secretKey) throws Exception {
		byte [] secretKeyBytes = secretKey.getBytes (Encodings.UTF8);
		
		Mac mac = Mac.getInstance (HMAC_SHA256_ALGORITHM);
	    mac.init (new SecretKeySpec (secretKeyBytes, HMAC_SHA256_ALGORITHM));
	    
		return new String (Base64.getEncoder ().encode (mac.doFinal (uri.getBytes (Encodings.UTF8))), Encodings.UTF8).trim ();
	}
	
}
