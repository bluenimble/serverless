package com.settletop.playground;

import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GetVersion extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (GetVersion.class);
	
	public static void main (String [] args) {
		new GetVersion ().run ();
	}

	public void run () {
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri ("/version"))
				.GET ()
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	} 
	
}
