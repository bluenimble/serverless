package com.settletop.playground.security;

import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.playground.ApiClient;

public class CheckToken extends ApiClient {
	
	private static final Logger Logger = LoggerFactory.getLogger (CheckToken.class);
	
	public static void main (String [] args) throws Exception {
		new CheckToken ().run ();
	}

	public void run () throws Exception {
		
		String uri = "/security/token/check";
		
		Object result = send (
			HttpRequest.newBuilder ()
				.uri (buildUri (uri))
				.header ("Authorization", token ())
				.GET ()
				.build (),
			ResponseType.Json
		);
		
		Logger.info ("Result ->\n" + result);
		
	}
	
}
