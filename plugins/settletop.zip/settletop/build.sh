#!/bin/sh

# set the version
VERSION=$1

# create dist
mkdir -p dist

# delete all build content
rm -fr build/*

# compile and create struct
mvn clean install

# tar/gz dist
tar cf settletop-server.tar.gz build/settletop-$VERSION
mv settletop-server.tar.gz dist/settletop-server.tar.gz

# run the docker file, send to repos

# git tag
