package com.settletop.platform.services.indexer.impls.elasticsearch;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.json.JsonArray;
import com.settletop.json.JsonException;
import com.settletop.json.JsonObject;
import com.settletop.platform.services.indexer.Indexer;
import com.settletop.utils.ContentTypes;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class ElasticSearchIndexer implements Indexer {
	
	private static final Logger Logger = LoggerFactory.getLogger (ElasticSearchIndexer.class);
	
	private static final String DATE_FORMAT	 		= "yyyy-MM-dd'T'HH:mm:ss'Z'";
	
	enum ResponseType {
		Json,
		Text,
		Binary
	}
	
	interface Index {
		String Mappings 	= "mappings";
		String Properties 	= "properties";
	}
	
	interface Document {
		String Id 			= "id";
		String Timestamp 	= "timestamp";
	}
	
	interface FieldsFilter {
		String Include = "include";
		String Exclude = "exclude";
	}
	
	interface ElasticSearch {
		
		String Source 			= "_source";
		String SourceIncludes 	= "_source_includes";
		String SourceExcludes 	= "_source_excludes";
		
		String Index			= "index";
		String _Index			= "_index";
		
		String Id				= "_id";
		
		String Query			= "query";
		
		interface Endpoints {
			String Create 			= "_create";
			String Search 			= "_search";
			String Bulk 			= "_bulk";
			String UpdateByQuery 	= "_update_by_query";
		}
		
	}
	
	private JsonObject 	spec;
	private String 		endpoint;
	private String 		authorization;
	private String		indexPrefix;
	
	public ElasticSearchIndexer (JsonObject spec, String authorization) {
		this.spec 			= spec;
		this.endpoint 		= Json.getString (this.spec, ElasticSearchService.Spec.Host);
		this.authorization 	= authorization;
		this.indexPrefix	= Json.getString (this.spec, ElasticSearchService.Spec.IndexPrefix);
	}

	@Override
	public void newIndex (String index, JsonObject schema) {
		if (Lang.isNullOrEmpty (index)) {
			throw new RuntimeException ("Missing - Index name");
		}
		
		Logger.debug ("Creating Index [" + index + "]");
		
		index = indexName (index);

		JsonObject indexPayload = 
			((JsonObject)Json.find (this.spec, ElasticSearchService.Spec.Templates, ElasticSearchService.Spec.NewIndex)).duplicate ();
		
		if (!Json.isNullOrEmpty (schema)) {
			JsonObject properties = (JsonObject)Json.find (indexPayload, Index.Mappings, Index.Properties);
			properties.putAll (schema);
		}
		
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (buildUri (index))
		  .header (HttpHeaders.Authorization, this.authorization)
		  .header (HttpHeaders.ContentType, ContentTypes.Json)
		  .PUT (HttpRequest.BodyPublishers.ofByteArray (indexPayload.toString (0, true).getBytes ()))
		  .build ();
		
		sendRequest (request, null);
	}
	
	@Override
	public void create (String index, JsonObject document) {
		if (Lang.isNullOrEmpty (index)) {
			throw new RuntimeException ("Missing - Index name");
		}

		index = indexName (index);

		String id = Json.getString (document, Document.Id);
		if (Lang.isNullOrEmpty (id)) {
			document.set (Document.Id, Lang.oid ());
		}
		
		if (!document.containsKey (Document.Timestamp)) {
			document.set (Document.Timestamp, utc ());
		}
		
		Logger.debug ("Indexing Document [" + id + "]");
		
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (buildUri (index + Lang.SLASH + id + Lang.SLASH + ElasticSearch.Endpoints.Create))
		  .header (HttpHeaders.Authorization, this.authorization)
		  .header (HttpHeaders.ContentType, ContentTypes.Json)
		  .POST (HttpRequest.BodyPublishers.ofByteArray (document.toString (0, true).getBytes ()))
		  .build ();
		
		sendRequest (request, null);
	}
	
	@Override
	public JsonObject get (String index, String id, JsonObject fields) {
		if (Lang.isNullOrEmpty (index)) {
			throw new RuntimeException ("Missing - Index name");
		}

		index = indexName (index);

		if (Lang.isNullOrEmpty (id)) {
			throw new RuntimeException ("Missing - Document Id");
		}
		String filter = null;

		String sIncludeFields = null;
		String sExcludeFields = null;
		
		JsonArray aIncludes = Json.getArray (fields, FieldsFilter.Include);
		if (!Json.isNullOrEmpty (aIncludes)) {
			if (sIncludeFields == null) {
				sIncludeFields = Lang.BLANK;
			}
			sIncludeFields = ElasticSearch.SourceIncludes + Lang.EQUALS + aIncludes.join (Lang.COMMA, false);
		}
		
		JsonArray aExcludes = Json.getArray (fields, FieldsFilter.Exclude);
		if (!Json.isNullOrEmpty (aExcludes)) {
			if (sExcludeFields == null) {
				sExcludeFields = Lang.BLANK;
			}
			sExcludeFields = ElasticSearch.SourceExcludes + Lang.EQUALS + aExcludes.join (Lang.COMMA, false);
		}
		
		if (sIncludeFields != null || sExcludeFields != null) {
			filter = Lang.QMARK;
			if (sIncludeFields != null) {
				filter += sIncludeFields;
			}
			if (sExcludeFields != null) {
				filter += ((sIncludeFields != null ? Lang.AMP : Lang.BLANK) + sExcludeFields);
			}
		}
		if (filter == null) {
			filter = Lang.BLANK;
		}
		
		Logger.debug ("Lookup Document [" + id + "]");
		
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (buildUri (index + Lang.SLASH + id + Lang.SLASH + ElasticSearch.Source + filter))
		  .header (HttpHeaders.Authorization, this.authorization)
		  .GET ()
		  .build ();
		
		return (JsonObject)sendRequest (request, ResponseType.Json);
	}
	
	@Override
	public void update (String index, String id, JsonObject object) {
	}
	
	@Override
	public void updateByQuery (String index, JsonObject query, JsonObject update) {
		if (Lang.isNullOrEmpty (index)) {
			throw new RuntimeException ("Missing - Index name");
		}

		index = indexName (index);
		
		update.set (ElasticSearch.Query, query);
		
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (buildUri (index + Lang.SLASH + ElasticSearch.Endpoints.UpdateByQuery))
		  .header (HttpHeaders.Authorization, this.authorization)
		  .header (HttpHeaders.ContentType, ContentTypes.Json)
		  .POST (HttpRequest.BodyPublishers.ofByteArray (update.toString (0, true).getBytes ()))
		  .build ();
		
		sendRequest (request, null);
	}
	
	@Override
	public void delete (String index, String id) {
	}
	
	@Override
	public void deleteByQuery (String index, JsonObject query) {
	}
	
	@Override
	public JsonObject search (String index, JsonObject query) {
		return null;
	}
	
	/**
	 * 
	 * { "index" : { "_index" : "test", "_id" : "1" } }
	 * { "field1" : "value1" }
	 *
	 **/
	@Override
	public void load (String index, List<JsonObject> documents) {
		if (Lang.isNullOrEmpty (index)) {
			throw new RuntimeException ("Missing - Index name");
		}
		
		index = indexName (index);

		if (documents == null || documents.isEmpty ()) {
			throw new RuntimeException ("Missing - objects to load");
		}
		
		Logger.debug ("Loading [" + documents.size () + "] documents into " + index);
		
		JsonObject loadDocumentHeader = 
			((JsonObject)Json.find (this.spec, ElasticSearchService.Spec.Templates, ElasticSearchService.Spec.LoadDocument)).duplicate ();
		
		JsonObject documentHeader = 
			Json.getObject (
				loadDocumentHeader, 
				ElasticSearch.Index
			);
		
		documentHeader.set (ElasticSearch._Index, index);
		
		StringBuilder sb = new StringBuilder ();
		for (JsonObject document : documents) {
			String id = Json.getString (document, Document.Id);
			document.remove (Document.Id);
			if (Lang.isNullOrEmpty (id)) {
				id = Lang.oid ();
			}
			documentHeader.set (ElasticSearch.Id, id);
			// append header
			sb.append (loadDocumentHeader.toString (0, true)).append (Lang.ENDLN);
			// append fields
			sb.append (document.toString (0, true)).append (Lang.ENDLN);
		}
		
		String payload = sb.toString ();
		
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (buildUri (ElasticSearch.Endpoints.Bulk))
		  .header (HttpHeaders.Authorization, this.authorization)
		  .header (HttpHeaders.ContentType, ContentTypes.XndJson)
		  .POST (HttpRequest.BodyPublishers.ofString (payload))
		  .build ();
		
		// clear the sb
		sb.setLength (0);
		
		// send request
		sendRequest (request, null);
	}
	
	private String utc () {
		SimpleDateFormat formatter = new SimpleDateFormat (DATE_FORMAT);
		formatter.setTimeZone (Lang.UTC_TZ);
		return formatter.format (Lang.utcTime ());
	}
	
	private URI buildUri (String sUri) {
		URI uri = null;
		try {
			uri = new URI (this.endpoint + Lang.SLASH + sUri);
		} catch (URISyntaxException e) {
			throw new RuntimeException (e);
		}
		return uri;
	}
	
	private String indexName (String index) {
		if (Lang.isNullOrEmpty (indexPrefix)) {
			return index;
		}
		return indexPrefix + index;
	}
	
	private Object sendRequest (HttpRequest request, ResponseType responseType) {
		Logger.debug (" -> Send HTTP Request " + request.uri ());
		
		HttpResponse<String> response = null;
		try {
			response = HttpClient.newHttpClient ().send (request, BodyHandlers.ofString ());
		} catch (Exception e) {
			throw new RuntimeException (e);
		}
		
		int code  = response.statusCode ();
		
		Logger.debug (" ->> Got ElasticSeaarch Response " + code);
		
		if (code != 200) {
			throw new RuntimeException (response.body ());
		}
		
		if (responseType == null) {
			return null;
		}
		
		switch (responseType) {
			case Text:
				return response.body ();
			case Json:
			try {
				return new JsonObject (response.body ());
			} catch (JsonException e) {
				throw new RuntimeException (e);
			}
			default:
				return null;
		}
	}
	
}
