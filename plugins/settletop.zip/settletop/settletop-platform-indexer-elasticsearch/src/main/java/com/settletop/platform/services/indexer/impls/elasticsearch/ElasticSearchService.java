package com.settletop.platform.services.indexer.impls.elasticsearch;

import java.util.Base64;

import com.settletop.json.JsonObject;
import com.settletop.platform.services.indexer.Indexer;
import com.settletop.platform.services.indexer.IndexerService;
import com.settletop.server.ApiServer;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class ElasticSearchService implements IndexerService {
	
	private static final String BasicAuthScheme		= "Basic ";
	
	interface Spec {
		String Host 			= "host";
		String Templates		= "templates";
			String NewIndex		= "newIndex";
			String LoadDocument	= "loadDocument";
		
		String Secrets 		= "secrets";
			String User 	= "user";
			String Password = "password";
			
		String IndexPrefix	= "indexPrefix";
	}

	private JsonObject 	spec;
	private String 		authorization;
	
	public void initialize (ApiServer server, JsonObject spec) {
		this.spec = spec;
		JsonObject secrets = server.getSecretsProvider ().lookup (Json.getString (spec, Spec.Secrets));
		if (secrets == null) {
			return;
		}
		String toEncode = Json.getString (secrets, Spec.User) + Lang.COLON + Json.getString (secrets, Spec.Password);
		this.authorization = 
			BasicAuthScheme + Base64.getEncoder ().encodeToString (toEncode.getBytes ());
	}
	
	public Indexer get () {
		return new ElasticSearchIndexer (this.spec, this.authorization);
	}
	
}
