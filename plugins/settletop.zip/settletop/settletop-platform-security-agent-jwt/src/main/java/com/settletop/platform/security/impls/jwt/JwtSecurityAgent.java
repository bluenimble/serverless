package com.settletop.platform.security.impls.jwt;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.settletop.ApiConsumer;
import com.settletop.ApiContext;
import com.settletop.ApiRequest;
import com.settletop.ApiResponse;
import com.settletop.ApiService;
import com.settletop.ApiServiceRegistry;
import com.settletop.impls.DefaultApiConsumer;
import com.settletop.json.JsonArray;
import com.settletop.json.JsonObject;
import com.settletop.platform.security.SecretsProvider;
import com.settletop.platform.security.SecurityAgent;
import com.settletop.platform.security.SecurityAgentException;
import com.settletop.server.ApiServer;
import com.settletop.utils.HttpHeaders;
import com.settletop.utils.Json;
import com.settletop.utils.Lang;

public class JwtSecurityAgent implements SecurityAgent {
	
	private static final Logger Logger = LoggerFactory.getLogger (JwtSecurityAgent.class);
	
	private static final Map<String, Object> Header = new HashMap<String, Object> ();
	static {
		Header.put ("alg", "HS512");
		Header.put ("typ", "JWT");
	}
	
	private static final String Issuer 		= "SettleTop";
	private static final String Consumer 	= "consumer";
	
	enum Errors {
		InvalidAuthorizationScheme,
		InvalidToken,
		NoEnoughRights,
		NoRoleFound
	}
	
	interface Spec {
		String Secrets = "secrets";
			String Value = "value";
		
		String Scheme 	= "scheme";
		String Age 		= "age"; // in minutes
	}
	
	interface Defaults {
		String 	Scheme  = "Bearer";
		int		Age		= 7 * 24 * 60; // 1 week
	}
	
	interface Collections {
		interface Role {
			String Rights = "rights";
		}
	}
	
	interface Output {
		String 	Token  		= "token";
		String	ExpiresAt	= "expiresAt";
		String	Age			= "age";
	}
	
	private JWTVerifier verifier;
	
	private SecretsProvider secretsProvider;
	
	private JsonObject spec;

	@Override
	public void initialize (ApiServer server, JsonObject spec) {
		this.secretsProvider = server.getSecretsProvider ();
		this.spec = spec;
		// Verifier Instance
		verifier = JWT.require (createAlgorithm ()).withIssuer (Issuer).build ();
	}
	
	@Override
	public ApiConsumer check (
		ApiContext context, ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification
	) throws SecurityAgentException {
		
		// check the service security/authorization/scheme
		String scheme = (String)Json.find (specification, ApiService.Spec.Security, ApiService.Spec.Authorization, ApiService.Spec.Scheme);
		if (!Schemes.TOKEN.equals (scheme)) {
			return new DefaultApiConsumer ((JsonObject)new JsonObject ().set (ApiConsumer.Fields.Tenant, ApiConsumer.Anonymous));
		}
		
	    String auth = request.getHeader (HttpHeaders.Authorization);
	    String [] aAuth = Lang.split (auth, Lang.SPACE, true);
	    
	    if (!aAuth[0].equals (Json.getString (this.spec, Spec.Scheme, Defaults.Scheme))) {
	    	throw new SecurityAgentException (401, Errors.InvalidAuthorizationScheme.toString ());
	    }
	    
	    ApiConsumer consumer = null;
	    try {
	    	DecodedJWT decoded = verifier.verify (aAuth[1]);
	    	consumer = new DefaultApiConsumer (new JsonObject (decoded.getClaim (Consumer).asString ()));
		} catch (Exception e) {
			Logger.debug (Lang.BLANK, e);
	    	throw new SecurityAgentException (401, Errors.InvalidToken.toString ());
		}
	    
	    // check rights if any
	    JsonArray requiredRights = (JsonArray)Json.find (specification, ApiService.Spec.Security, ApiService.Spec.Authorization, ApiService.Spec.Rights);
	    if (Json.isNullOrEmpty (requiredRights)) {
	    	return consumer;
	    }
	    
	    // get the Role
	    JsonObject role = context.getDatabase (null, false).get (Collections.Role.class.getSimpleName (), consumer.get (ApiConsumer.Fields.Role));
	    if (role == null) {
	    	throw new SecurityAgentException (401, Errors.NoRoleFound.toString ());
	    }
	    
	    JsonArray rights = (JsonArray)consumer.get (Collections.Role.Rights);
	    
    	for (int i = 0; i < requiredRights.count (); i++) {
    		String requiredRight = (String)requiredRights.get (i);
    		if (!rights.contains (requiredRight)) {
    	    	throw new SecurityAgentException (403, Errors.NoEnoughRights.toString ());
    		}
    	}
	    
	    return consumer;
	}
	
	@Override
	public JsonObject issueToken (JsonObject payload, int ageInMinutes) {
		if (ageInMinutes == 0) {
			ageInMinutes = 180 * 24 * 60;
		}
		if (ageInMinutes < 0) {
			ageInMinutes = Json.getInteger (this.spec, Spec.Age, Defaults.Age);
		}
		
		int age = ageInMinutes * 60 * 1000;
		
		Date expiresAt = new Date (new Date ().getTime () + age);
		
		String token = 
			JWT.create ()
				.withIssuer (Issuer)
				.withHeader (Header)
				.withExpiresAt (expiresAt)
				.withClaim (Consumer, payload.toString (0, true))
				.sign (createAlgorithm ());
		
		return (JsonObject)new JsonObject ()
			.set (Output.Token, token)
			.set (Output.ExpiresAt, expiresAt)
			.set (Output.Age, ageInMinutes);
	}

	private Algorithm createAlgorithm () {
		String secretsKey = Json.getString (this.spec, Spec.Secrets);
		return Algorithm.HMAC512 (Json.getString (secretsProvider.lookup (secretsKey), Spec.Value));
	}

}
