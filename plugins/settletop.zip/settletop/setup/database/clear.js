db.OPERATION.remove( { } );
db.DATASET.remove( { } );
