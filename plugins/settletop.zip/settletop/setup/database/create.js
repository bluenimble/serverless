db.createCollection('USER');
db.createCollection('WORKSPACE');
db.createCollection('TENANT');
db.createCollection('ROLE');
db.createCollection('APPLICATION');
db.createCollection('DATASET');
db.createCollection('OPERATION');