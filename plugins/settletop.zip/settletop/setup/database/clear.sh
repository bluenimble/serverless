#!/bin/sh

mongo "mongodb+srv://api:Ad%40m2010@displaystream-primary-9zlqv.mongodb.net:28015/settletop-dev" clear.js