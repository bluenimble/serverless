#!/bin/sh

Env=$1

mongo "mongodb+srv://api:Ad%40m2010@displaystream-primary-9zlqv.mongodb.net:28015/settletop-dev" create.js