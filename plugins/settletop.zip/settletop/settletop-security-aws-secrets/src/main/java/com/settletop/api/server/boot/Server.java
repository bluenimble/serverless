package com.settletop.api.server.boot;

import com.settletop.api.server.ApiServer;
import com.settletop.api.server.StartApiServerException;
import com.settletop.api.server.impls.DefaultApiServer;

public class Server {

	public static void main (String[] args) throws StartApiServerException {
		final ApiServer apiServer = new DefaultApiServer ();
		apiServer.start ();
		
		Runtime.getRuntime ().addShutdownHook (new Thread () {
			public void run () {
				apiServer.stop ();
			}
		});
	}

}
