package com.settletop.api;

import com.settletop.api.json.JsonObject;

public interface ApiResponse {
	
	void 			writeHeader 		(String name, String value);
	
	void 			writeText 			(String text);
	void 			writeHtml 			(String html);
	void 			writeJson 			(JsonObject json);
	void 			writeBytes 			(byte [] bytes);
	
	void			writeError			(int code, String message);
	
}
