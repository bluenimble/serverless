package com.settletop.api.platform.security;

import com.settletop.api.json.JsonObject;
import com.settletop.api.server.ApiServer;

public interface SecretsProvider {

	void 		initialize 	(ApiServer server) throws Exception;
	JsonObject 	lookup 		(String path);
	
}
