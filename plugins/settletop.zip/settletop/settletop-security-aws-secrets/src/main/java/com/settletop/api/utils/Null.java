package com.settletop.api.utils;

import java.io.Serializable;

public final class Null implements Serializable {

	private static final long serialVersionUID = -4074799016571685758L;
	
	public static final Null Instance = new Null ();

    protected final Object clone() {
        return this;
    }

    public boolean equals (Object object) {
        return object == null || object == this;
    }

    public String toString () {
        return "!NULL!";
    }
    
}


