package com.settletop.api.server;

public class StartApiServerException extends Exception {

	private static final long serialVersionUID = 3526264775480364319L;
	
	public StartApiServerException (String message) {
		super (message);
	}

	public StartApiServerException (Throwable th) {
		super (th);
	}

	public StartApiServerException (String message, Throwable th) {
		super (message, th);
	}

}
