package com.settletop.api.impls.readers;

import java.io.IOException;
import java.io.InputStream;

import com.settletop.api.ApiRequestBodyReader;
import com.settletop.api.utils.Json;

public class ApiRequestBodyJsonReader implements ApiRequestBodyReader {

	@Override
	public Object read (InputStream stream) throws IOException {
		try {
			return Json.load (stream);
		} catch (Exception ex) {
			throw new IOException (ex.getMessage (), ex);
		}
	}

}
