package com.settletop.api.impls;

import java.io.File;
import java.io.FileFilter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.api.ApiService;
import com.settletop.api.ApiServiceRegistry;
import com.settletop.api.ApiServiceWrapper;
import com.settletop.api.json.JsonObject;
import com.settletop.api.utils.BeanUtils;
import com.settletop.api.utils.Json;
import com.settletop.api.utils.Lang;
import com.settletop.api.utils.WildcardCompiler;
import com.settletop.api.utils.WildcardMatcher;

public class DefaultApiServiceRegistry implements ApiServiceRegistry {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServiceRegistry.class);
	
	private static final String JsonExtension	= ".json";
	private static final String ServicesFolder 	= "services";
	
	interface Service {
		String Id			= "id";
		String Endpoint		= "endpoint";
		String Verb			= "verb";
		String Spi			= "spi";
	}
	
	interface Defaults {
		String Verb = "GET";
	}
	
	private File home;
	
	private Map<String, String> 	servicesByPath 	= new HashMap<String, String>();
	private Map<String, JsonObject> serviceSpecs 	= new HashMap<String, JsonObject>();

	private Map<String, ApiService> services 		= new HashMap<String, ApiService>();
	
	public DefaultApiServiceRegistry (File home) throws Exception {
		this.home = home;
		this.loadServices ();
	}
	
	public ApiServiceWrapper lookup (String id) {
		return new ApiServiceWrapper (serviceSpecs.get (id), services.get (id));
	}
	
	public ApiServiceWrapper lookup (String verb, String path) {
		String endpoint = verb.toUpperCase () + Lang.COLON + path;
		Logger.info ("Find service for endpoint " + endpoint);
		String serviceId = servicesByPath.get (endpoint);
		if (serviceId != null) {
			return new ApiServiceWrapper (serviceSpecs.get (serviceId), services.get (serviceId));
		}
		Iterator<String> paths = servicesByPath.keySet ().iterator ();
		while (paths.hasNext ()) {
			String sPath 	= paths.next ();
			String sId 		= servicesByPath.get (sPath);
			WildcardMatcher matcher = new WildcardMatcher (WildcardCompiler.compile (endpoint), sPath);
			if (matcher.find ()) {
				return this.lookup (sId);
			}
		}
		return null;
	}
	
	private void loadServices () throws Exception {
		File servicesFolder = new File (this.home, ServicesFolder);
		if (!servicesFolder.exists ()) {
			return;
		}
		this.loadServices (servicesFolder);
	}
	
	private void loadServices (File folder) throws Exception {
		File [] files = folder.listFiles (new FileFilter () {
			public boolean accept (File file) {
				return file.isDirectory () || file.getName ().endsWith (JsonExtension);
			}
		});
		
		for (File file : files) {
			if (file.isDirectory ()) {
				this.loadServices (file);
				continue;
			}
			
			this.addService (Json.load (file));
		}
	}
	
	private void addService (JsonObject serviceSpec) throws Exception {
		String endpoint = Json.getString (serviceSpec, Service.Endpoint); 
		
		boolean doubleColonFound = false;
		
		String [] accessors = Lang.split (endpoint, Lang.SLASH);
		for (int i = 0; i < accessors.length; i++) {
			String accessor = accessors [i];
			if (accessor.startsWith (Lang.COLON + Lang.COLON)) {
				if (doubleColonFound) {
					break;
				}
				doubleColonFound = true;
				endpoint = Lang.replace (endpoint, accessor, Lang.STAR + Lang.STAR);
			} else if (accessor.startsWith (Lang.COLON)) {
				endpoint = Lang.replace (endpoint, accessor, Lang.STAR);
			}
		}
		
		
		String serviceId = Json.getString (serviceSpec, Service.Id);
		if (Lang.isNullOrEmpty (serviceId)) {
			serviceId = Lang.oid ();
		}
		
		serviceSpecs.put (serviceId, serviceSpec);
		
		servicesByPath.put (
			Json.getString (serviceSpec, Service.Verb, Defaults.Verb).toUpperCase () + Lang.COLON + endpoint, 
			serviceId
		);
		
		String serviceSpi = Json.getString (serviceSpec, Service.Spi);
		if (Lang.isNullOrEmpty (serviceSpi)) {
			return;
		}
		
		services.put (serviceId, (ApiService)BeanUtils.create (serviceSpi, null));
	}
	
}
