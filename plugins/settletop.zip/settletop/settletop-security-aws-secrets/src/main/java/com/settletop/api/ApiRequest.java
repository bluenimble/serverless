package com.settletop.api;

import java.util.Set;

public interface ApiRequest {
	
	interface Verbs {
		String Get 		= "GET";
		String Post 	= "POST";
		String Put 		= "PUT";
		String Delete 	= "DELETE";
		String Patch	= "PATCH";
	}
	
	String 			getVerb 			();
	String 			getPath 			();
	String 			getContentType		();
	
	Set<String> 	enumerateParameters ();
	Set<String> 	enumerateHeaders 	();
    
	Object			getParameter		(String name);
	String			getHeader			(String name);
	
	Object			getBody				();
	
}
