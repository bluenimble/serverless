package com.settletop.api.json;

import java.util.HashSet;
import java.util.Set;

import com.settletop.api.utils.Json;
import com.settletop.api.utils.Lang;

public abstract class AbstractEmitter implements JsonEmitter {
	
	protected static final Set<Class<?>> CastTypes = new HashSet<Class<?>> ();
	static {
		CastTypes.add (Integer.class); CastTypes.add (Integer.TYPE);
		CastTypes.add (Long.class); CastTypes.add (Long.TYPE);
		CastTypes.add (Double.class); CastTypes.add (Double.TYPE);
		CastTypes.add (Float.class); CastTypes.add (Float.TYPE);
		CastTypes.add (Boolean.class); CastTypes.add (Boolean.TYPE);
	}
	
	private boolean		pretty;
	
	private String 		tab 	= Lang.TAB;
	private String 		space 	= Lang.SPACE;
	
	protected int 		indent;
	protected boolean	cast; 
	
	public void onStartObject (JsonObject o, boolean root) {
		write (Lang.OBJECT_OPEN);
		if (pretty) {
			onEndLn ();
			if (o.count () > 0) {
				indent++;
			}
		} 
	}

	public void onEndObject (JsonObject o, boolean root) {
		if (pretty) {
			onEndLn ();
		} 
		if (pretty && o.count () > 0) {
			indent--;
		}
		indent ();
		write (Lang.OBJECT_CLOSE);
	}

	public void onStartProperty (JsonObject p, String name, boolean isLast) {
		indent ();
		writeName (name);
		if (pretty) {
			write (space);
		}
	}

	public void onEndProperty (JsonObject p, String name, boolean isLast) {
		if (!isLast) {
			write (Lang.COMMA);
			if (pretty) {
				onEndLn ();
			} 
		}
	}

	public void onStartArray (JsonArray a) {
		write (Lang.ARRAY_OPEN);
		if (pretty) {
			onEndLn ();
			if (a.count () > 0) {
				indent++;
			}
		} 
	}

	public void onEndArray (JsonArray a) {
		if (pretty) {
			onEndLn ();
		} 
		if (pretty && a.count () > 0) {
			indent--;
		}
		indent ();
		write (Lang.ARRAY_CLOSE);
	}

	public void onValue (JsonEntity p, String name, Object value) {
		if (value == null) {
			write (Lang.NULL);
		} else {
			if (!cast || !CastTypes.contains (value.getClass ())) {
				write (Lang.QUOTE);
			}
			
			write (Json.escape (String.valueOf (value)));
			
			if (!cast || !CastTypes.contains (value.getClass ())) {
				write (Lang.QUOTE);
			}
		}
	}

	protected void writeName (String name) {
		write (Lang.QUOTE);
		write (Json.escape (name));
		write (Lang.QUOTE);
		write (Lang.COLON);
	}

	protected void onEndLn () {
		write (Lang.ENDLN);
	}

	public void onStartArrayValue (JsonArray array, Object value, boolean isLast) {
		indent ();
	}

	public void onEndArrayValue (JsonArray array, Object value, boolean isLast) {
		if (!isLast) {
			write (Lang.COMMA);
			if (pretty) {
				onEndLn ();
			} 
		}
	}
	
	public AbstractEmitter prettify () {
		pretty = true;
		return this; 
	}
	
	public AbstractEmitter tab (String tab) {
		this.tab = tab;
		return this;
	}
	
	public AbstractEmitter cast (boolean cast) {
		this.cast = cast;
		return this;
	}
	
	private void indent () {
		if (indent <= 0) {
			return;
		}
		for (int i = 0; i < indent; i++) {
			write (tab);	
		}
	}
	
}
