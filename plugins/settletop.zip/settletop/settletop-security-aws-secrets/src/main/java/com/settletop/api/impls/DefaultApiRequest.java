package com.settletop.api.impls;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.settletop.api.ApiRequest;
import com.settletop.api.ApiRequestBodyReader;
import com.settletop.api.utils.Encodings;
import com.settletop.api.utils.Lang;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

public class DefaultApiRequest implements ApiRequest {
	
	private static final String ContentTypeHeader = "CONTENT-TYPE";
	
	private static final Map<String, ApiRequestBodyReader> Readers = new HashMap<String, ApiRequestBodyReader>();
	
	private HttpExchange exchange;
	
	private Map<String, String> headers = new HashMap<String, String>();;
	private Map<String, Object> parameters;
	
	private Object body;
	
	public DefaultApiRequest (HttpExchange exchange) throws Exception {
		this.exchange = exchange;
		
		this.readHeaders 	();
		this.readParameters ();
		this.readBody 		();
		
	}

	public String getVerb () {
		return exchange.getRequestMethod ().toUpperCase ();
	}

	public String getPath () {
		return exchange.getRequestURI ().getPath ();
	}

	public Set<String> enumerateParameters () {
		if (parameters == null) {
			return EmptySet;
		}
		return parameters.keySet ();
	}

	public Set<String> enumerateHeaders () {
		return exchange.getRequestHeaders ().keySet ();
	}

	public Object getParameter (String name) {
		if (name == null) {
			return null;
		}
		if (parameters == null) {
			return null;
		}
		return parameters.get (name);
	}

	public String getHeader (String name) {
		if (name == null) {
			return null;
		}
		return headers.get (name.toUpperCase ());
	}

	public String getContentType () {
		return this.getHeader (ContentTypeHeader);
	}
	
	public Object getBody () {
		return this.body;
	}
	
	private void readBody () throws Exception {
		String verb = this.getVerb ();
		if (!verb.equals (Verbs.Post) || !verb.equals (Verbs.Put)) {
			return;
		}
		ApiRequestBodyReader reader = Readers.get (this.getContentType ());
		if (reader == null) {
			return;
		}
		InputStream stream = exchange.getRequestBody ();
		if (stream == null) {
			return;
		}
		this.body = reader.read (exchange.getRequestBody ());
	}
	
	private void readHeaders () {
		Headers headers = exchange.getRequestHeaders ();
		Iterator<String> names = headers.keySet ().iterator ();
		while (names.hasNext ()) {
			String name = names.next ();
			this.headers.put (name.toUpperCase (), headers.get (name).get (0));
		}
	}
	
	private void readParameters () {
		String query = exchange.getRequestURI ().getQuery ();
		if (Lang.isNullOrEmpty (query)) {
			return;
		}
		parameters = new HashMap<String, Object>();
		String [] aQuery = Lang.split (exchange.getRequestURI ().getQuery (), Lang.AMP);
		for (String nv : aQuery) {
			if (nv.indexOf (Lang.EQUALS) <= 0) {
				parameters.put (decode (nv), true);
				continue;
			}
			String [] anv = Lang.split (nv, Lang.EQUALS);
			parameters.put (decode (anv [0]), decode (anv [1]));
		}
	}
	
	private String decode (String encoded) {
	    try {
	        return encoded == null ? null : URLDecoder.decode (encoded, Encodings.UTF8);
	    } catch (UnsupportedEncodingException e) {
	        return null;
	    }
	}
	
}
