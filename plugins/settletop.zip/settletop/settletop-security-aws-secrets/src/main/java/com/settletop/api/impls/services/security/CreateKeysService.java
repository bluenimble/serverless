package com.settletop.api.impls.services.security;

import com.settletop.api.ApiRequest;
import com.settletop.api.ApiResponse;
import com.settletop.api.ApiService;
import com.settletop.api.ApiServiceExecutionException;
import com.settletop.api.ApiServiceRegistry;
import com.settletop.api.json.JsonObject;

public class CreateKeysService implements ApiService {
	
	public void execute (ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification)
		throws ApiServiceExecutionException {
		
	}

}
