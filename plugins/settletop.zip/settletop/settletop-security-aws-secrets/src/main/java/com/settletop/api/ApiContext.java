package com.settletop.api;

import com.settletop.api.platform.services.database.Database;
import com.settletop.api.platform.services.indexer.Indexer;

public interface ApiContext {
	
	Database 	getDatabase (String name, boolean trx);
	Indexer 	getIndexer  (String name);
    
}
