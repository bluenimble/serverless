package com.settletop.api.impls.readers;

import java.util.Scanner;

import com.settletop.api.json.JsonException;
import com.settletop.api.json.JsonObject;

public class MultilineJson {

	private Scanner scanner;
	
	public MultilineJson (Scanner scanner) {
		this.scanner = scanner;
	}
	
	public boolean hasNext () {
		return scanner.hasNextLine ();
	}

	public JsonObject next () throws JsonException {
		return new JsonObject (scanner.next ());
	}
	
}
