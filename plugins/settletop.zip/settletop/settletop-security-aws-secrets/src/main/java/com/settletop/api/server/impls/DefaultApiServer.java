package com.settletop.api.server.impls;

import java.io.File;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.api.ApiServiceRegistry;
import com.settletop.api.impls.DefaultApiServiceRegistry;
import com.settletop.api.json.JsonObject;
import com.settletop.api.platform.security.SecretsProvider;
import com.settletop.api.platform.security.impls.PlainSecretsProvider;
import com.settletop.api.server.ApiServer;
import com.settletop.api.server.StartApiServerException;
import com.settletop.api.utils.BeanUtils;
import com.settletop.api.utils.Json;
import com.settletop.api.utils.Lang;
import com.sun.net.httpserver.HttpServer;

public class DefaultApiServer implements ApiServer {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServer.class);

	private static final String ServerConfig 		= "server.json";
	
	private static final String InitializeMethod	= "initialize";
	
	interface Spec {
		String Host 			= "host";
		String Port 			= "port";
		String ThreadPool		= "threadPool";
		String Context			= "context";
		String Clazz			= "class";

		interface Platform {
			String SecretsProvider	= "secretsProvider";
			String Services 		= "services";
			String ServiceSpec		= "spec";
		}
	}
	
	interface Defaults {
		String 	Host 		= "localhost";
		Integer Port 		= 9090;
		Integer ThreadPool	= 100;
		String 	Context		= "/";
	}
	
	private File home;
	
	private JsonObject config;
	private HttpServer server;
	
	private SecretsProvider	   	secretsProvider;
	private ApiServiceRegistry 	serviceRegistry;
	private Map<String, Object>	platformServices = new HashMap<String, Object> ();
	
	public void start () throws StartApiServerException {
		
		this.home = new File (System.getProperty ("user.dir"));
		
		this.config = null;
		
		File configFile = new File (home, ServerConfig);
		
		if (configFile.exists ()) {
			// load the server config
			try {
				this.config = Json.load (configFile);
			} catch (Exception e) {
				throw new StartApiServerException (e);
			}
		} else {
			this.config = new JsonObject ();
		}
		
		try {
			// initialize the secrets provider & platform services
			this.initializePlatformServices ();
			
			// create a server instance
			String host = Json.getString (this.config, Spec.Host, Defaults.Host);
			server = HttpServer.create (
				Lang.isNullOrEmpty (host) ?
				new InetSocketAddress (
					Json.getInteger (this.config, Spec.Port, Defaults.Port)
				) : 
				new InetSocketAddress (
					Json.getString (this.config, Spec.Host, Defaults.Host), 
					Json.getInteger (this.config, Spec.Port, Defaults.Port)
				),
				0
			);
			
			// load services specifications
			this.serviceRegistry = new DefaultApiServiceRegistry (home);
			
			// start the server instance
			ThreadPoolExecutor threadPoolExecutor = 
				(ThreadPoolExecutor)Executors.newFixedThreadPool (Json.getInteger (this.config, Spec.ThreadPool, Defaults.ThreadPool));
			
			server.createContext (Json.getString (this.config, Spec.Context, Defaults.Context), new DefaultApiServerHandler (this));
			server.setExecutor (threadPoolExecutor);
			server.start ();
			Logger.info ("Server started and listening on port " + Json.getInteger (this.config, Spec.Port, Defaults.Port));
		} catch (Exception e) {
			throw new StartApiServerException (e);
		}
	}
	
	public void stop () {
		server.stop (0);
	}
	
	public File getHome () {
		return home;
	}
	
	public JsonObject getConfiguration () {
		return config;
	}
	
	public SecretsProvider getSecretsProvider () {
		return secretsProvider;
	}
	
	public ApiServiceRegistry getServiceRegistry () {
		return serviceRegistry;
	}
	
	public Object getPlatformService (String name) {
		return platformServices.get (name);
	}
	
	private void initializePlatformServices () throws Exception {
		// setup the secrets provider
		String secretsProvider = (String)Json.find (this.config, Spec.Platform.class.getSimpleName ().toLowerCase (), Spec.Platform.SecretsProvider);
		if (secretsProvider == null) {
			secretsProvider = PlainSecretsProvider.class.getName ();
		}
		Logger.info ("  -> Using Secrets Provider " + secretsProvider);
		
		this.secretsProvider = (SecretsProvider)BeanUtils.create (secretsProvider, null);
		Method initMethod = this.secretsProvider.getClass ().getMethod (InitializeMethod, new Class [] { ApiServer.class });
		initMethod.invoke (this.secretsProvider, new Object [] { this });
		
		// platform services
		JsonObject platformServices = (JsonObject)Json.find (this.config, Spec.Platform.class.getSimpleName ().toLowerCase (), Spec.Platform.Services);
		if (platformServices == null) {
			return;
		}
		
		Logger.info ("  -> Found " + platformServices.size () + " platform services");
		
		Iterator<String> keys = platformServices.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			Logger.info ("  -> Initialize platform service " + key);
			JsonObject service = Json.getObject (platformServices, key);
			Object platformService = BeanUtils.create (Json.getString (service, Spec.Clazz), null);
			initMethod = platformService.getClass ().getMethod (InitializeMethod, new Class [] { ApiServer.class, JsonObject.class });
			initMethod.invoke (platformService, new Object [] { this, Json.getObject (service, Spec.Platform.ServiceSpec) });
			this.platformServices.put (key, platformService);
		}
	}
	
}
