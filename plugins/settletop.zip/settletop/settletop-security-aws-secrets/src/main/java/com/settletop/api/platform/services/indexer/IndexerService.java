package com.settletop.api.platform.services.indexer;

import com.settletop.api.json.JsonObject;
import com.settletop.api.server.ApiServer;

public class IndexerService {
	
	interface Spec {
		String Host 	= "host";
	}

	private JsonObject spec;
	
	public void initialize (ApiServer server, JsonObject spec) {
		this.spec = spec;
	}
	
	public Indexer get () {
		return new Indexer (this.spec);
	}
	
}
