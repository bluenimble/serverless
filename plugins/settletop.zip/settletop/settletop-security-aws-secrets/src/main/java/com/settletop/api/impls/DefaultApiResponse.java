package com.settletop.api.impls;

import java.io.OutputStream;

import com.settletop.api.ApiResponse;
import com.settletop.api.json.JsonObject;
import com.settletop.api.utils.ContentTypes;
import com.settletop.api.utils.Encodings;
import com.settletop.api.utils.Lang;
import com.sun.net.httpserver.HttpExchange;

public class DefaultApiResponse implements ApiResponse {
	
	private static final String ContentType = "Content-Type";
	
	private HttpExchange exchange;
	
	public DefaultApiResponse (HttpExchange exchange) {
		this.exchange = exchange;
	}

	@Override
	public void writeText (String text) {
		writeHeader (ContentType, ContentTypes.Text + "; charset=" + Encodings.UTF8); 
		write (exchange, 200, text.getBytes ());
	}

	@Override
	public void writeHtml (String html) {
		writeHeader (ContentType, ContentTypes.Html + "; charset=" + Encodings.UTF8); 
		write (exchange, 200, html.getBytes ());
	}

	@Override
	public void writeJson (JsonObject json) {
		writeHeader (ContentType, ContentTypes.Json + "; charset=" + Encodings.UTF8); 
		write (exchange, 200, json.toString (0, true).getBytes ());
	}

	@Override
	public void writeBytes (byte[] bytes) {
		write (exchange, 200, bytes);
	}

	@Override
	public void writeError (int code, String message) {
		if (message == null) {
			message = Lang.BLANK;
		}
		write (exchange, code, String.valueOf (message).getBytes ());
	}

	@Override
	public void writeHeader (String name, String value) {
		exchange.getResponseHeaders().set (name, value);
	}
	
	private static void write (HttpExchange exchange, int code, byte [] content) {
		OutputStream os = null;
		try {
			exchange.sendResponseHeaders (code, content.length);
			os = exchange.getResponseBody ();
			os.write (content);
		} catch (Exception ex) {
			// ignore
		} finally {
			try {
				if (os != null) {
					os.close ();
				}
			} catch (Exception ex) {
				// ignore
			}
		}
	}

}
