package com.settletop.api.impls;

import com.settletop.api.ApiContext;
import com.settletop.api.platform.services.database.Database;
import com.settletop.api.platform.services.database.DatabaseService;
import com.settletop.api.platform.services.indexer.Indexer;
import com.settletop.api.platform.services.indexer.IndexerService;
import com.settletop.api.server.impls.DefaultApiServer;
import com.settletop.api.utils.Lang;

public class DefaultApiContext implements ApiContext {
	
	interface Defaults {
		String Database = "database.default";
		String Indexer 	= "indexer.default";
	}
	
	private DefaultApiServer server;
	
	public DefaultApiContext (DefaultApiServer server) {
		this.server = server;
	}

	@Override
	public Database getDatabase (String name, boolean trx) {
		if (Lang.isNullOrEmpty (name)) {
			name = Defaults.Database;
		}
		Object oService = server.getPlatformService (name);
		if (!(oService instanceof DatabaseService)) {
			return null;
		}
		return ((DatabaseService)oService).get (trx);
	}

	@Override
	public Indexer getIndexer (String name) {
		if (Lang.isNullOrEmpty (name)) {
			name = Defaults.Indexer;
		}
		Object oService = server.getPlatformService (name);
		if (!(oService instanceof IndexerService)) {
			return null;
		}
		return ((IndexerService)oService).get ();
	}

}
