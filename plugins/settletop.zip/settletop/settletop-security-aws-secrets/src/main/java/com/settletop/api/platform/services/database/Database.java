package com.settletop.api.platform.services.database;

import static com.mongodb.client.model.Filters.eq;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.MongoClient;
import com.mongodb.TransactionOptions;
import com.mongodb.WriteConcern;
import com.mongodb.client.ClientSession;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;

import com.settletop.api.json.JsonObject;
import com.settletop.api.utils.Json;

public class Database {
	
	interface Internal {
		String Id = "_id";
	}
	
	interface Fields {
		String Id 			= "id";
		String Timestamp 	= "timestamp";
	}
	
	interface Dsl {
		String Set 			= "set";
		String Unset 		= "unset";
	}
	
	private MongoDatabase 	mdb;
	private ClientSession 	session;
	
	public Database (MongoClient client, MongoDatabase mdb, boolean trx) {
		if (!trx) {
			return;
		}
		session = client.startSession ();
		session.startTransaction (TransactionOptions.builder ().writeConcern (WriteConcern.ACKNOWLEDGED).build ());
	}
	
	public void create (String collection, JsonObject object) {
		MongoCollection<Document> mc = this.getCollection (collection);
		if (collection == null) {
			return;
		}
		Document document = new Document ();
		document.append (Fields.Timestamp, new Date ());
		Iterator<String> keys = object.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			document.append (key, object.get (key));
		}
		if (this.session == null) {
			mc.insertOne (document);
		} else {
			mc.insertOne (this.session, document);
		}
		object.set (Fields.Id, document.get (Internal.Id).toString ());
	}
	
	public JsonObject get (String collection, Object id) {
		MongoCollection<Document> mc = this.getCollection (collection);
		if (collection == null) {
			return null;
		}
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		Document document = null;
		if (this.session == null) {
			document = mc.find (eq (Internal.Id, _id)).first ();
		} else {
			document = mc.find (this.session, eq (Internal.Id, _id)).first ();
		}
		return toJson (document);
	}
	
	public void update (String collection, Object id, JsonObject object) {
		MongoCollection<Document> mc = this.getCollection (collection);
		if (collection == null) {
			return;
		}
		
		Document update = new Document ();
		if (object.containsKey (Dsl.Set)) {
			Document set = new Document ();
			update.put (Dsl.Set, set);
			copy (Json.getObject (object, Dsl.Set), set);
		}
		if (object.containsKey (Dsl.Unset)) {
			Document unset = new Document ();
			update.put (Dsl.Unset, unset);
			copy (Json.getObject (object, Dsl.Unset), unset);
		}
		
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		if (this.session == null) {
			mc.updateOne (eq (Internal.Id, _id), update);
		} else {
			mc.updateOne (this.session, eq (Internal.Id, _id), update);
		}
	}
	
	public int delete (String collection, Object id) {
		MongoCollection<Document> mc = this.getCollection (collection);
		if (collection == null) {
			return 0;
		}
		Object _id = id;
		if (!(id instanceof ObjectId) && ObjectId.isValid (String.valueOf (id))) {
			_id = new ObjectId (String.valueOf (id));
		}
		
		DeleteResult result = null;
		
		if (session == null) {
			result = mc.deleteOne (eq (Internal.Id, _id));
		} else {
			result = mc.deleteOne (session, eq (Internal.Id, _id));
		}
		
		return (int)result.getDeletedCount ();
	}
	
	public List<JsonObject> find (String collection, JsonObject query) {
		return null;
	}
	
	public void commit () {
		if (this.session == null) {
			return;
		}
		this.session.commitTransaction ();
	}

	public void rollback () {
		if (this.session == null) {
			return;
		}
		this.session.abortTransaction ();
	}
	
	private MongoCollection<Document> getCollection (String collection) {
		return mdb.getCollection (collection.toUpperCase ());
	}
	
	private JsonObject toJson (Document document) {
		if (document == null) {
			return null;
		}
		JsonObject object = new JsonObject ();
		Iterator<String> fields = document.keySet ().iterator ();
		while (fields.hasNext ()) {
			String field = fields.next ();
			object.set (field == Internal.Id ? Fields.Id : field, document.get (field));
		}
		return object;
	}
	
	private void copy (JsonObject object, Document document) {
		Iterator<String> keys = object.keys ();
		while (keys.hasNext ()) {
			String key = keys.next ();
			document.append (key, object.get (key));
		}
	}
	
}
