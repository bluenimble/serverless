package com.settletop.api;

public interface ApiServiceRegistry {
	
	ApiServiceWrapper lookup 			(String id);
	ApiServiceWrapper lookup 			(String verb, String path);
	
}
