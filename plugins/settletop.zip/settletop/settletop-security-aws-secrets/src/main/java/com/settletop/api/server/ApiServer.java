package com.settletop.api.server;

import java.io.File;

import com.settletop.api.ApiServiceRegistry;
import com.settletop.api.platform.security.SecretsProvider;

public interface ApiServer {

	void start 			() throws StartApiServerException;
	void stop 			();
	
	File 				getHome 			();
	
	SecretsProvider 	getSecretsProvider 	();
	ApiServiceRegistry 	getServiceRegistry 	();
	Object 				getPlatformService 	(String name);
	
}
