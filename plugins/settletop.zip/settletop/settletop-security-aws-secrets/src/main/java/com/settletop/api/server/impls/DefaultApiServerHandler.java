package com.settletop.api.server.impls;

import java.io.IOException;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.api.ApiServiceWrapper;
import com.settletop.api.impls.DefaultApiRequest;
import com.settletop.api.impls.DefaultApiResponse;
import com.settletop.api.utils.Lang;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class DefaultApiServerHandler implements HttpHandler {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServerHandler.class);
	
	private static final String ServiceNotFound = "Service not found";
	
	private DefaultApiServer server;
	
	public DefaultApiServerHandler (DefaultApiServer server) {
		this.server = server;
	}

	public void handle (HttpExchange exchange) throws IOException {
		Logger.info ("New Request " + exchange.getRequestMethod () + Lang.COLON + exchange.getRequestURI ().getPath ());
		ApiServiceWrapper serviceWrapper = 
			this.server.getServiceRegistry ().lookup (
				exchange.getRequestMethod (),
				exchange.getRequestURI ().getPath ()
			);
		if (serviceWrapper == null) {
			write (exchange, 404, ServiceNotFound);
			return;
		}
		
		Logger.info ("Found service matching endpoint -> " + serviceWrapper.getService ().getClass ().getSimpleName ());
		
		try {
			serviceWrapper.getService ().execute (new DefaultApiRequest (exchange), new DefaultApiResponse (exchange), server.getServiceRegistry (), serviceWrapper.getSpecification ());
		} catch (Exception e) {
			throw new IOException (e);
		}
	}
	
	private void write (HttpExchange exchange, int code, String text) {
		OutputStream os = null;
		try {
			exchange.sendResponseHeaders (code, text.getBytes ().length);
			os = exchange.getResponseBody ();
			os.write (text.getBytes ());
		} catch (Exception ex) {
			// ignore
		} finally {
			try {
				if (os != null) {
					os.close ();
				}
			} catch (Exception ex) {
				// ignore
			}
		}
	}

}
