package com.settletop.api.impls.services.applications;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.settletop.api.ApiRequest;
import com.settletop.api.ApiResponse;
import com.settletop.api.ApiService;
import com.settletop.api.ApiServiceExecutionException;
import com.settletop.api.ApiServiceRegistry;
import com.settletop.api.json.JsonObject;
import com.settletop.api.server.impls.DefaultApiServer;

public class CreateApplicationService implements ApiService {
	
	private static final Logger Logger = LoggerFactory.getLogger (DefaultApiServer.class);

	public void execute (ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification)
		throws ApiServiceExecutionException {
		
		Logger.info ("Service " + specification);
		
		response.writeHeader ("Koala", "Here");
		
		response.writeText ("Hello " + request.getParameter ("name"));
		
	}

}
