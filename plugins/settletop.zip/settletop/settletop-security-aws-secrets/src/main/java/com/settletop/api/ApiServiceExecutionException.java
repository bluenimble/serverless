package com.settletop.api;

public class ApiServiceExecutionException extends Exception {

	private static final long serialVersionUID = 3526264775480364319L;
	
	public ApiServiceExecutionException (String message) {
		super (message);
	}

	public ApiServiceExecutionException (Throwable th) {
		super (th);
	}

	public ApiServiceExecutionException (String message, Throwable th) {
		super (message, th);
	}

}
