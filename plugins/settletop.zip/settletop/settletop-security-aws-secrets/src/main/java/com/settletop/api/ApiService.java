package com.settletop.api;

import com.settletop.api.json.JsonObject;

public interface ApiService {
	
	void execute (ApiRequest request, ApiResponse response, ApiServiceRegistry registry, JsonObject specification) throws ApiServiceExecutionException;
    
}
