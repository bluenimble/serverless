package com.settletop.api.platform.security.impls;

import java.io.File;

import com.settletop.api.json.JsonObject;
import com.settletop.api.platform.security.SecretsProvider;
import com.settletop.api.server.ApiServer;
import com.settletop.api.utils.Json;

public class PlainSecretsProvider implements SecretsProvider {
	
	private static final String SecretsFile = "secrets.json";
	
	private JsonObject secrets;
	
	public PlainSecretsProvider () {
	}
	
	@Override
	public void initialize (ApiServer server) throws Exception {
		this.secrets = Json.load (new File (server.getHome (), SecretsFile));
	}

	@Override
	public JsonObject lookup (String name) {
		return Json.getObject (secrets, name);
	}

}
