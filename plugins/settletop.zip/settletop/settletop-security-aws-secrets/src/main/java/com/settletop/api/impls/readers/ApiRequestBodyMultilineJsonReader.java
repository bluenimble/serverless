package com.settletop.api.impls.readers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import com.settletop.api.ApiRequestBodyReader;

public class ApiRequestBodyMultilineJsonReader implements ApiRequestBodyReader {
	
	@Override
	public Object read (InputStream stream) throws IOException {
		return new MultilineJson (new Scanner (stream));
	}

}
