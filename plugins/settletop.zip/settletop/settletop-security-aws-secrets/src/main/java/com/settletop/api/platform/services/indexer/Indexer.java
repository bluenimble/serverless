package com.settletop.api.platform.services.indexer;

import java.net.URI;
import java.net.http.HttpRequest;

import com.settletop.api.json.JsonObject;
import com.settletop.api.utils.Json;

public class Indexer {
	
	private JsonObject spec;
	
	public Indexer (JsonObject spec) {
		this.spec = spec;
	}
	
	public JsonObject get (String index, String id) {
		return null;
	}
	
	public void create (String index, JsonObject object) throws Exception {
		HttpRequest request = HttpRequest.newBuilder ()
		  .uri (new URI (Json.getString (this.spec, IndexerService.Spec.Host)))
		  .GET ()
		  .build ();
	}
	
	public void update (String index, String id, JsonObject object) {
	}
	
	public void updateByQuery (String index, JsonObject query, JsonObject update) {
	}
	
	public void delete (String index, String id) {
	}
	
	public void deleteByQuery (String index, JsonObject query) {
	}
	
	public JsonObject search (String index, JsonObject query) {
		return null;
	}
	
	public void bulk (String index, String payload) {
	}
	
}
